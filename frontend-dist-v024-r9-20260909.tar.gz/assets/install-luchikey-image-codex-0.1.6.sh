#!/usr/bin/env bash
set -euo pipefail
umask 077

PLUGIN_NAME="luchikey-image"
VERSION="0.1.6"
EXPECTED_ZIP_SHA256="c960f602217675f2de095fd382f1c5d7c639c7b51b2ab9155feaf8a0ef2a39f4"
ZIP_URL="https://sub2api.luchikey.com/assets/luchikey-image-codex-plugin-0.1.6.zip"
MAX_ZIP_BYTES=8388608
MAX_ARCHIVE_FILE_BYTES=2097152
MAX_ARCHIVE_EXPANDED_BYTES=4194304
EXPECTED_ARCHIVE_ENTRIES=$'luchikey-image/.codex-plugin/plugin.json\nluchikey-image/.mcp.json\nluchikey-image/README.md\nluchikey-image/image-endpoint-policy.mjs\nluchikey-image/image-errors.mjs\nluchikey-image/image-io.mjs\nluchikey-image/image-output-transaction.mjs\nluchikey-image/scripts/luchikey-image-mcp.mjs\nluchikey-image/scripts/output-transaction-smoke.mjs\nluchikey-image/scripts/smoke-mcp-client.mjs\nluchikey-image/scripts/smoke-mock-server.mjs\nluchikey-image/scripts/smoke-test.mjs\nluchikey-image/skills/luchikey-image/SKILL.md'

: "${HOME:?HOME must be set to install the LuchiKey Image plugin}"
case "$HOME" in
  /*) ;;
  *)
    echo "HOME must be an absolute path." >&2
    exit 1
    ;;
esac

MARKETPLACE_ROOT="${HOME}/.agents/plugins"
MARKETPLACE_FILE="${MARKETPLACE_ROOT}/marketplace.json"
PLUGIN_PARENT="${HOME}/plugins"
PLUGIN_ROOT="${PLUGIN_PARENT}/${PLUGIN_NAME}"
CONFIG_ROOT="${HOME}/.luchikey-image"
CONFIG_FILE="${CONFIG_ROOT}/config.json"
CODEX_ROOT="${CODEX_HOME:-${HOME}/.codex}"
case "$CODEX_ROOT" in
  /*) ;;
  *)
    echo "CODEX_HOME must be an absolute path when it is set." >&2
    exit 1
    ;;
esac
CODEX_CONFIG_FILE="${CODEX_ROOT}/config.toml"
LOCK_DIR="${HOME}/.luchikey-image-install.lock"

TMP_ROOT=""
ZIP_PATH=""
EXTRACT_ROOT=""
EXTRACTED_PLUGIN=""
MARKETPLACE_EXPECTED=""
LOCK_HELD=0
TRANSACTION_ACTIVE=0
KEY_STATE="not_configured"
READ_API_KEY=""
TTY_ECHO_DISABLED=0

TX_TARGETS=()
TX_BACKUP_DIRS=()
TX_HAD_ORIGINAL=()
PENDING_STAGES=()

require_command() {
  local command_name="$1"
  local install_hint="$2"
  if ! command -v "$command_name" >/dev/null 2>&1; then
    echo "$install_hint" >&2
    exit 1
  fi
}

assert_safe_directory_chain() {
  local trust_root="$1"
  local target_directory="$2"
  local relative current component
  local -a components=()
  if [ "$trust_root" != "/" ]; then trust_root="${trust_root%/}"; fi
  if [ "$target_directory" != "/" ]; then target_directory="${target_directory%/}"; fi
  if [ -z "$trust_root" ] || [ -z "$target_directory" ] || [ ! -d "$trust_root" ]; then
    echo "The installer path trust root is unavailable: ${trust_root:-unknown}" >&2
    return 1
  fi
  case "$target_directory" in
    "$trust_root") return 0 ;;
    "$trust_root"/*) ;;
    *)
      echo "Refusing an installer directory outside its declared root: $target_directory" >&2
      return 1
      ;;
  esac

  relative="${target_directory#"$trust_root"/}"
  current="$trust_root"
  IFS='/' read -r -a components <<< "$relative"
  for component in "${components[@]}"; do
    case "$component" in
      ""|.|..)
        echo "Refusing an unsafe installer path component in: $target_directory" >&2
        return 1
        ;;
    esac
    current="${current}/${component}"
    if [ -L "$current" ]; then
      echo "Refusing a symlinked installer directory ancestor: $current" >&2
      return 1
    fi
    if [ -e "$current" ] && [ ! -d "$current" ]; then
      echo "Refusing a non-directory installer path ancestor: $current" >&2
      return 1
    fi
  done
}

assert_install_paths_safe() {
  assert_safe_directory_chain "$HOME" "$MARKETPLACE_ROOT"
  assert_safe_directory_chain "$HOME" "$PLUGIN_PARENT"
  assert_safe_directory_chain "$HOME" "$CONFIG_ROOT"
  case "$CODEX_ROOT" in
    "$HOME"|"$HOME"/*) assert_safe_directory_chain "$HOME" "$CODEX_ROOT" ;;
    *) assert_safe_directory_chain "$(dirname "$CODEX_ROOT")" "$CODEX_ROOT" ;;
  esac
}

acquire_install_lock() {
  if ! mkdir "$LOCK_DIR" 2>/dev/null; then
    echo "Another LuchiKey Image installation appears to be running." >&2
    echo "If no installer is running, remove this stale lock and try again: $LOCK_DIR" >&2
    exit 1
  fi
  chmod 700 "$LOCK_DIR"
  printf '%s\n' "$$" > "${LOCK_DIR}/pid"
  chmod 600 "${LOCK_DIR}/pid"
  LOCK_HELD=1
}

restore_tty_echo() {
  if [ "$TTY_ECHO_DISABLED" -eq 1 ] && [ -r /dev/tty ]; then
    stty echo < /dev/tty 2>/dev/null || true
    TTY_ECHO_DISABLED=0
  fi
}

restore_saved_trap() {
  local saved_trap="$1"
  local signal_name="$2"
  if [ -n "$saved_trap" ]; then
    eval "$saved_trap"
  else
    trap - "$signal_name"
  fi
}

release_install_lock() {
  if [ "$LOCK_HELD" -ne 1 ]; then
    return 0
  fi
  rm -f "${LOCK_DIR}/pid"
  if ! rmdir "$LOCK_DIR" 2>/dev/null; then
    echo "Warning: could not remove installer lock directory: $LOCK_DIR" >&2
  fi
  LOCK_HELD=0
}

cleanup_transaction_backups() {
  local backup_dir
  for backup_dir in "${TX_BACKUP_DIRS[@]}"; do
    if [ -n "$backup_dir" ] && [ -d "$backup_dir" ] && [ ! -L "$backup_dir" ]; then
      chmod -R u+rwX "$backup_dir" 2>/dev/null || true
      if ! rm -rf "$backup_dir"; then
        echo "Warning: could not remove transaction backup: $backup_dir" >&2
      fi
    fi
  done
  TX_TARGETS=()
  TX_BACKUP_DIRS=()
  TX_HAD_ORIGINAL=()
}

rollback_transaction() {
  local index target backup_dir had_original rollback_failed=0
  if [ "$TRANSACTION_ACTIVE" -ne 1 ]; then
    return 0
  fi

  for ((index=${#TX_TARGETS[@]} - 1; index >= 0; index -= 1)); do
    target="${TX_TARGETS[$index]}"
    backup_dir="${TX_BACKUP_DIRS[$index]}"
    had_original="${TX_HAD_ORIGINAL[$index]}"

    if [ -e "$target" ] || [ -L "$target" ]; then
      if ! mv "$target" "${backup_dir}/replacement"; then
        echo "Rollback could not move the replacement aside: $target" >&2
        rollback_failed=1
        continue
      fi
    fi

    if [ "$had_original" -eq 1 ]; then
      if ! mv "${backup_dir}/original" "$target"; then
        echo "Rollback could not restore the original path: $target" >&2
        rollback_failed=1
      fi
    fi
  done

  TRANSACTION_ACTIVE=0
  if [ "$rollback_failed" -ne 0 ]; then
    echo "Rollback backups were preserved for manual recovery:" >&2
    printf '  %s\n' "${TX_BACKUP_DIRS[@]}" >&2
    return 1
  fi
  return 0
}

finalize_transaction() {
  TRANSACTION_ACTIVE=0
  cleanup_transaction_backups
}

cleanup() {
  local exit_code=$?
  local stage
  trap - EXIT
  restore_tty_echo

  if [ "$TRANSACTION_ACTIVE" -eq 1 ]; then
    if rollback_transaction; then
      cleanup_transaction_backups
    fi
  fi

  for stage in "${PENDING_STAGES[@]}"; do
    if [ -d "$stage" ] && [ ! -L "$stage" ]; then
      chmod -R u+rwX "$stage" 2>/dev/null || true
      rm -rf "$stage"
    elif [ -e "$stage" ] || [ -L "$stage" ]; then
      rm -f "$stage"
    fi
  done

  if [ -n "$TMP_ROOT" ] && [ -d "$TMP_ROOT" ] && [ ! -L "$TMP_ROOT" ]; then
    chmod -R u+rwX "$TMP_ROOT" 2>/dev/null || true
    rm -rf "$TMP_ROOT"
  fi
  release_install_lock
  exit "$exit_code"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
trap 'exit 129' HUP

atomic_replace_path() {
  local staged_path="$1"
  local target_path="$2"
  local stage_parent target_parent target_name backup_dir had_original=0

  stage_parent="$(cd "$(dirname "$staged_path")" && pwd -P)"
  target_parent="$(cd "$(dirname "$target_path")" && pwd -P)"
  if [ "$stage_parent" != "$target_parent" ]; then
    echo "Refusing a non-atomic cross-directory replacement for: $target_path" >&2
    return 1
  fi

  target_name="$(basename "$target_path")"
  backup_dir="$(mktemp -d "${target_parent}/.${target_name}.backup.XXXXXXXX")"
  chmod 700 "$backup_dir"

  if [ -e "$target_path" ] || [ -L "$target_path" ]; then
    if ! mv "$target_path" "${backup_dir}/original"; then
      rmdir "$backup_dir" 2>/dev/null || true
      return 1
    fi
    had_original=1
  fi

  if ! mv "$staged_path" "$target_path"; then
    if [ "$had_original" -eq 1 ]; then
      if ! mv "${backup_dir}/original" "$target_path"; then
        echo "The replacement failed and the original is preserved at ${backup_dir}/original" >&2
        return 1
      fi
    fi
    rmdir "$backup_dir" 2>/dev/null || true
    return 1
  fi

  if [ "$TRANSACTION_ACTIVE" -eq 1 ]; then
    TX_TARGETS+=("$target_path")
    TX_BACKUP_DIRS+=("$backup_dir")
    TX_HAD_ORIGINAL+=("$had_original")
  else
    chmod -R u+rwX "$backup_dir" 2>/dev/null || true
    if ! rm -rf "$backup_dir"; then
      echo "Warning: could not remove replacement backup: $backup_dir" >&2
    fi
  fi
}

atomic_replace_file() {
  local staged_file="$1"
  local target_file="$2"
  if [ ! -f "$staged_file" ] || [ -L "$staged_file" ]; then
    echo "Atomic file replacement requires a staged regular file: $staged_file" >&2
    return 1
  fi
  if [ -L "$target_file" ]; then
    echo "Refusing to replace a symlinked file target: $target_file" >&2
    return 1
  fi
  if [ -e "$target_file" ] && [ ! -f "$target_file" ]; then
    echo "Refusing to replace a non-file path: $target_file" >&2
    return 1
  fi
  chmod 600 "$staged_file"
  atomic_replace_path "$staged_file" "$target_file"
}

atomic_replace_directory() {
  local staged_directory="$1"
  local target_directory="$2"
  if [ ! -d "$staged_directory" ] || [ -L "$staged_directory" ]; then
    echo "Atomic directory replacement requires a staged directory: $staged_directory" >&2
    return 1
  fi
  if [ -L "$target_directory" ]; then
    echo "Refusing to replace a symlinked directory target: $target_directory" >&2
    return 1
  fi
  if [ -e "$target_directory" ] && [ ! -d "$target_directory" ]; then
    echo "Refusing to replace a non-directory path: $target_directory" >&2
    return 1
  fi
  chmod 700 "$staged_directory"
  atomic_replace_path "$staged_directory" "$target_directory"
}

download_release() {
  echo "Downloading LuchiKey Image Codex plugin ${VERSION}..."
  rm -f "$ZIP_PATH"
  # The JavaScript is single-quoted so shell expansion cannot alter it.
  # shellcheck disable=SC2016
  if ! curl -q --fail --silent --show-error \
    --proto '=https' \
    --tlsv1.2 \
    --connect-timeout 15 \
    --max-time 120 \
    --max-filesize "$MAX_ZIP_BYTES" \
    "$ZIP_URL" \
    | node -e '
const fs = require("node:fs");
const { Transform } = require("node:stream");
const { pipeline } = require("node:stream/promises");

const [zipPath, maxBytesRaw] = process.argv.slice(1);
const maxBytes = Number(maxBytesRaw);
let total = 0;
const limiter = new Transform({
  transform(chunk, _encoding, callback) {
    total += chunk.length;
    if (total > maxBytes) {
      callback(new Error(`download exceeds ${maxBytes} bytes`));
      return;
    }
    callback(null, chunk);
  },
});

(async () => {
  try {
    await pipeline(
      process.stdin,
      limiter,
      fs.createWriteStream(zipPath, { flags: "wx", mode: 0o600 }),
    );
    fs.chmodSync(zipPath, 0o600);
  } catch (error) {
    try { fs.unlinkSync(zipPath); } catch {}
    console.error(`Plugin download failed: ${error.message}`);
    process.exitCode = 1;
  }
})();
' "$ZIP_PATH" "$MAX_ZIP_BYTES"; then
    rm -f "$ZIP_PATH"
    echo "Could not download the pinned LuchiKey Image plugin release." >&2
    return 1
  fi

  local zip_size
  zip_size="$(node -e 'const fs=require("node:fs"); process.stdout.write(String(fs.statSync(process.argv[1]).size));' "$ZIP_PATH")"
  if ! [[ "$zip_size" =~ ^[0-9]+$ ]] || [ "$zip_size" -le 0 ] || [ "$zip_size" -gt "$MAX_ZIP_BYTES" ]; then
    echo "Downloaded plugin archive has an invalid size: ${zip_size:-unknown}" >&2
    return 1
  fi
}

verify_archive_checksum() {
  local actual_zip_sha256
  actual_zip_sha256="$(node -e 'const fs=require("node:fs"); const crypto=require("node:crypto"); process.stdout.write(crypto.createHash("sha256").update(fs.readFileSync(process.argv[1])).digest("hex"));' "$ZIP_PATH")"
  if [ "$actual_zip_sha256" != "$EXPECTED_ZIP_SHA256" ]; then
    echo "Downloaded plugin checksum mismatch. Expected $EXPECTED_ZIP_SHA256 but got $actual_zip_sha256." >&2
    return 1
  fi
}

validate_release_archive() {
  node - "$ZIP_PATH" "$PLUGIN_NAME" "$VERSION" "$MAX_ZIP_BYTES" "$MAX_ARCHIVE_FILE_BYTES" "$MAX_ARCHIVE_EXPANDED_BYTES" "$EXPECTED_ARCHIVE_ENTRIES" <<'JS'
const fs = require("node:fs");
const zlib = require("node:zlib");

const [
  zipPath,
  pluginName,
  expectedVersion,
  maxZipBytesRaw,
  maxFileBytesRaw,
  maxExpandedBytesRaw,
  expectedEntriesRaw,
] = process.argv.slice(2);
const maxZipBytes = Number(maxZipBytesRaw);
const maxFileBytes = Number(maxFileBytesRaw);
const maxExpandedBytes = Number(maxExpandedBytesRaw);
const expectedEntries = expectedEntriesRaw.split("\n");
const expectedSet = new Set(expectedEntries);

function fail(message) {
  throw new Error(`Unsafe plugin archive: ${message}`);
}

function requireRange(buffer, offset, length, label) {
  if (!Number.isSafeInteger(offset) || !Number.isSafeInteger(length) || offset < 0 || length < 0 || offset + length > buffer.length) {
    fail(`${label} is outside the archive`);
  }
}

function decodeEntryName(bytes) {
  for (const byte of bytes) {
    if (byte < 0x20 || byte > 0x7e) fail("entry names must be printable ASCII");
  }
  const name = bytes.toString("ascii");
  if (!name || name.startsWith("/") || name.includes("\\") || name.includes("\0")) {
    fail(`invalid entry name: ${JSON.stringify(name)}`);
  }
  const parts = name.split("/");
  if (parts.some((part) => !part || part === "." || part === "..")) {
    fail(`traversal or empty path segment: ${name}`);
  }
  return name;
}

const crcTable = Array.from({ length: 256 }, (_, index) => {
  let value = index;
  for (let bit = 0; bit < 8; bit += 1) {
    value = (value & 1) ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
  }
  return value >>> 0;
});

function crc32(bytes) {
  let checksum = 0xffffffff;
  for (const byte of bytes) {
    checksum = crcTable[(checksum ^ byte) & 0xff] ^ (checksum >>> 8);
  }
  return (checksum ^ 0xffffffff) >>> 0;
}

if (expectedEntries.length !== 13 || expectedSet.size !== 13) {
  fail("installer allowlist must contain exactly 13 unique files");
}
for (const entry of expectedEntries) decodeEntryName(Buffer.from(entry, "ascii"));

const archive = fs.readFileSync(zipPath);
if (archive.length <= 0 || archive.length > maxZipBytes) fail("archive size is out of bounds");
if (archive.length < 22) fail("end-of-central-directory record is missing");

const eocdOffset = archive.length - 22;
if (archive.readUInt32LE(eocdOffset) !== 0x06054b50) fail("archive must have one canonical end record and no trailing data");
const diskNumber = archive.readUInt16LE(eocdOffset + 4);
const centralDisk = archive.readUInt16LE(eocdOffset + 6);
const diskEntries = archive.readUInt16LE(eocdOffset + 8);
const totalEntries = archive.readUInt16LE(eocdOffset + 10);
const centralSize = archive.readUInt32LE(eocdOffset + 12);
const centralOffset = archive.readUInt32LE(eocdOffset + 16);
const commentLength = archive.readUInt16LE(eocdOffset + 20);
if (diskNumber !== 0 || centralDisk !== 0 || diskEntries !== 13 || totalEntries !== 13) fail("multi-disk, ZIP64, or unexpected entry count");
if (commentLength !== 0 || centralOffset + centralSize !== eocdOffset) fail("archive comments, gaps, or trailing records are not allowed");
requireRange(archive, centralOffset, centralSize, "central directory");

const entries = [];
const seenNames = new Set();
const seenLocalOffsets = new Set();
let totalExpanded = 0;
let cursor = centralOffset;
for (let index = 0; index < totalEntries; index += 1) {
  requireRange(archive, cursor, 46, "central directory entry");
  if (archive.readUInt32LE(cursor) !== 0x02014b50) fail("invalid central directory signature");

  const versionMadeBy = archive.readUInt16LE(cursor + 4);
  const versionNeeded = archive.readUInt16LE(cursor + 6);
  const flags = archive.readUInt16LE(cursor + 8);
  const method = archive.readUInt16LE(cursor + 10);
  const checksum = archive.readUInt32LE(cursor + 16);
  const compressedSize = archive.readUInt32LE(cursor + 20);
  const expandedSize = archive.readUInt32LE(cursor + 24);
  const nameLength = archive.readUInt16LE(cursor + 28);
  const extraLength = archive.readUInt16LE(cursor + 30);
  const entryCommentLength = archive.readUInt16LE(cursor + 32);
  const diskStart = archive.readUInt16LE(cursor + 34);
  const externalAttributes = archive.readUInt32LE(cursor + 38);
  const localOffset = archive.readUInt32LE(cursor + 42);
  const fullLength = 46 + nameLength + extraLength + entryCommentLength;
  requireRange(archive, cursor, fullLength, "central directory entry body");

  const nameBytes = archive.subarray(cursor + 46, cursor + 46 + nameLength);
  const name = decodeEntryName(nameBytes);
  const unixMode = (externalAttributes >>> 16) & 0xffff;
  if ((versionMadeBy >>> 8) !== 3 || (unixMode & 0o170000) !== 0o100000 || (externalAttributes & 0x10) !== 0) {
    fail(`entry is not a regular Unix file: ${name}`);
  }
  if ((flags & 0xf7ff) !== 0 || (method !== 0 && method !== 8)) fail(`unsupported or unsafe ZIP flags for ${name}`);
  if (versionNeeded > 20 || extraLength !== 0 || entryCommentLength !== 0 || diskStart !== 0) fail(`non-canonical ZIP metadata for ${name}`);
  if (expandedSize > maxFileBytes || compressedSize > maxZipBytes) fail(`entry size is out of bounds: ${name}`);
  totalExpanded += expandedSize;
  if (totalExpanded > maxExpandedBytes) fail("total expanded size exceeds the installer limit");
  if (!expectedSet.has(name)) fail(`unexpected archive entry: ${name}`);
  if (seenNames.has(name) || seenLocalOffsets.has(localOffset)) fail(`duplicate archive entry: ${name}`);
  seenNames.add(name);
  seenLocalOffsets.add(localOffset);

  entries.push({
    name,
    nameBytes: Buffer.from(nameBytes),
    flags,
    method,
    checksum,
    compressedSize,
    expandedSize,
    localOffset,
    versionNeeded,
  });
  cursor += fullLength;
}
if (cursor !== centralOffset + centralSize || seenNames.size !== expectedSet.size) fail("central directory has missing or extra entries");
for (const expected of expectedEntries) {
  if (!seenNames.has(expected)) fail(`archive is missing ${expected}`);
}

cursor = 0;
let pluginManifestBytes = null;
for (const entry of [...entries].sort((left, right) => left.localOffset - right.localOffset)) {
  if (entry.localOffset !== cursor) fail(`local records contain a gap, overlap, or hidden entry before ${entry.name}`);
  requireRange(archive, cursor, 30, `local header for ${entry.name}`);
  if (archive.readUInt32LE(cursor) !== 0x04034b50) fail(`invalid local header for ${entry.name}`);

  const localVersionNeeded = archive.readUInt16LE(cursor + 4);
  const localFlags = archive.readUInt16LE(cursor + 6);
  const localMethod = archive.readUInt16LE(cursor + 8);
  const localChecksum = archive.readUInt32LE(cursor + 14);
  const localCompressedSize = archive.readUInt32LE(cursor + 18);
  const localExpandedSize = archive.readUInt32LE(cursor + 22);
  const localNameLength = archive.readUInt16LE(cursor + 26);
  const localExtraLength = archive.readUInt16LE(cursor + 28);
  const localHeaderLength = 30 + localNameLength + localExtraLength;
  requireRange(archive, cursor, localHeaderLength, `local header body for ${entry.name}`);
  const localName = archive.subarray(cursor + 30, cursor + 30 + localNameLength);

  if (
    localVersionNeeded !== entry.versionNeeded
    || localFlags !== entry.flags
    || localMethod !== entry.method
    || localChecksum !== entry.checksum
    || localCompressedSize !== entry.compressedSize
    || localExpandedSize !== entry.expandedSize
    || localExtraLength !== 0
    || !localName.equals(entry.nameBytes)
  ) {
    fail(`central and local metadata disagree for ${entry.name}`);
  }

  const dataStart = cursor + localHeaderLength;
  const dataEnd = dataStart + entry.compressedSize;
  if (dataEnd > centralOffset) fail(`compressed data overlaps the central directory for ${entry.name}`);
  const compressed = archive.subarray(dataStart, dataEnd);
  let expanded;
  try {
    expanded = entry.method === 0
      ? Buffer.from(compressed)
      : zlib.inflateRawSync(compressed, { maxOutputLength: maxFileBytes + 1 });
  } catch (error) {
    fail(`could not safely expand ${entry.name}: ${error.message}`);
  }
  if (expanded.length !== entry.expandedSize || expanded.length > maxFileBytes) fail(`expanded size mismatch for ${entry.name}`);
  if (crc32(expanded) !== entry.checksum) fail(`CRC mismatch for ${entry.name}`);
  if (entry.name === `${pluginName}/.codex-plugin/plugin.json`) pluginManifestBytes = expanded;
  cursor = dataEnd;
}
if (cursor !== centralOffset) fail("archive contains unindexed local data or hidden entries");
if (!pluginManifestBytes) fail("plugin.json is missing");

let pluginManifest;
try {
  pluginManifest = JSON.parse(pluginManifestBytes.toString("utf8"));
} catch (error) {
  fail(`plugin.json is invalid JSON: ${error.message}`);
}
if (!pluginManifest || pluginManifest.name !== pluginName || pluginManifest.version !== expectedVersion) {
  fail(`plugin.json must declare name ${pluginName} and version ${expectedVersion}`);
}
JS
}

verify_installed_release_bytes() {
  local installed_root="$1"
  node - "$EXTRACTED_PLUGIN" "$installed_root" "$PLUGIN_NAME" "$EXPECTED_ARCHIVE_ENTRIES" <<'JS'
const fs = require("node:fs");
const path = require("node:path");

const sourceRoot = process.argv[2];
const installedRoot = process.argv[3];
const pluginName = process.argv[4];
const expectedEntries = process.argv[5].split("\n");
const expectedFiles = expectedEntries.map((entry) => {
  const prefix = `${pluginName}/`;
  if (!entry.startsWith(prefix)) throw new Error(`Invalid installer allowlist entry: ${entry}`);
  return entry.slice(prefix.length);
}).sort();
const expectedDirectories = [...new Set(expectedFiles.flatMap((file) => {
  const parts = file.split("/");
  const directories = [];
  for (let index = 1; index < parts.length; index += 1) {
    directories.push(parts.slice(0, index).join("/"));
  }
  return directories;
}))].sort();

function scanTree(root) {
  const rootStat = fs.lstatSync(root);
  if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) throw new Error(`Plugin root is not a regular directory: ${root}`);
  const files = [];
  const directories = [];

  function visit(absoluteDirectory, relativeDirectory) {
    for (const name of fs.readdirSync(absoluteDirectory).sort()) {
      const absolute = path.join(absoluteDirectory, name);
      const relative = relativeDirectory ? `${relativeDirectory}/${name}` : name;
      const stat = fs.lstatSync(absolute);
      if (stat.isSymbolicLink()) throw new Error(`Symlink is not allowed in installed plugin: ${relative}`);
      if (stat.isDirectory()) {
        directories.push(relative);
        visit(absolute, relative);
      } else if (stat.isFile()) {
        files.push(relative);
      } else {
        throw new Error(`Non-regular installed plugin entry: ${relative}`);
      }
    }
  }
  visit(root, "");
  return { files: files.sort(), directories: directories.sort() };
}

function requireExactList(actual, expected, label) {
  if (actual.length !== expected.length || actual.some((value, index) => value !== expected[index])) {
    throw new Error(`${label} does not match the reviewed release`);
  }
}

const sourceTree = scanTree(sourceRoot);
const installedTree = scanTree(installedRoot);
requireExactList(sourceTree.files, expectedFiles, "Extracted file list");
requireExactList(sourceTree.directories, expectedDirectories, "Extracted directory list");
requireExactList(installedTree.files, expectedFiles, "Installed file list");
requireExactList(installedTree.directories, expectedDirectories, "Installed directory list");

for (const relative of expectedFiles) {
  const sourceBytes = fs.readFileSync(path.join(sourceRoot, ...relative.split("/")));
  const installedBytes = fs.readFileSync(path.join(installedRoot, ...relative.split("/")));
  if (!sourceBytes.equals(installedBytes)) throw new Error(`Installed file bytes differ: ${relative}`);
}
JS
}

secure_release_tree_permissions() {
  local root="$1"
  local entry
  while IFS= read -r -d '' entry; do
    chmod 700 "$entry"
  done < <(find "$root" -type d -print0)
  while IFS= read -r -d '' entry; do
    chmod 600 "$entry"
  done < <(find "$root" -type f -print0)
}

stage_release_directory() {
  local source_root="$1"
  local target_root="$2"
  local target_parent target_name staged_root
  target_parent="$(dirname "$target_root")"
  target_name="$(basename "$target_root")"
  mkdir -p "$target_parent"
  chmod 700 "$target_parent"
  staged_root="$(mktemp -d "${target_parent}/.${target_name}.stage.XXXXXXXX")"
  chmod 700 "$staged_root"
  if ! cp -R "${source_root}/." "$staged_root/"; then
    rm -rf "$staged_root"
    return 1
  fi
  secure_release_tree_permissions "$staged_root"
  if ! verify_installed_release_bytes "$staged_root"; then
    rm -rf "$staged_root"
    return 1
  fi
  printf '%s\n' "$staged_root"
}

prepare_marketplace_stage() {
  mkdir -p "$MARKETPLACE_ROOT"
  chmod 700 "$MARKETPLACE_ROOT"
  MARKETPLACE_STAGE="$(mktemp "${MARKETPLACE_ROOT}/.marketplace.json.stage.XXXXXXXX")"
  chmod 600 "$MARKETPLACE_STAGE"
  PENDING_STAGES+=("$MARKETPLACE_STAGE")

  MARKETPLACE_NAME="$(node - "$MARKETPLACE_FILE" "$MARKETPLACE_STAGE" "$PLUGIN_NAME" <<'JS'
const fs = require("node:fs");

const marketplaceFile = process.argv[2];
const stagedFile = process.argv[3];
const pluginName = process.argv[4];
const entry = {
  name: pluginName,
  source: { source: "local", path: `./plugins/${pluginName}` },
  policy: { installation: "AVAILABLE", authentication: "ON_USE" },
  category: "Productivity",
};
let marketplace = {
  name: "personal",
  interface: { displayName: "Personal" },
  plugins: [],
};

let existing = null;
try {
  existing = JSON.parse(fs.readFileSync(marketplaceFile, "utf8").replace(/^\uFEFF/, ""));
} catch (error) {
  if (error.code !== "ENOENT") {
    throw new Error("Existing marketplace.json is invalid; refusing to replace it.");
  }
}
if (existing !== null) {
  if (!existing || typeof existing !== "object" || Array.isArray(existing)) {
    throw new Error("Existing marketplace.json must contain a JSON object.");
  }
  if (typeof existing.name !== "string" || !Array.isArray(existing.plugins)) {
    throw new Error("Existing marketplace.json must contain a marketplace name and plugins list.");
  }
  const candidateName = String(existing.name || "").trim();
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/.test(candidateName)) {
    throw new Error("Existing marketplace.json has an unsafe marketplace name.");
  }
  marketplace = existing;
  marketplace.name = candidateName;
  if (existing.interface !== undefined) {
    if (!existing.interface || typeof existing.interface !== "object" || Array.isArray(existing.interface)) {
      throw new Error("Existing marketplace.json has an invalid interface object.");
    }
    if (existing.interface.displayName !== undefined && typeof existing.interface.displayName !== "string") {
      throw new Error("Existing marketplace.json has an invalid display name.");
    }
    if (existing.interface.displayName === undefined) {
      marketplace.interface.displayName = "Personal";
    } else {
      marketplace.interface.displayName = existing.interface.displayName;
    }
  }
  if (existing.interface === undefined) {
    marketplace.interface = { displayName: "Personal" };
  }
  marketplace.plugins = existing.plugins.filter((plugin) => {
    if (!plugin || typeof plugin !== "object" || Array.isArray(plugin) || typeof plugin.name !== "string") {
      throw new Error("Existing marketplace.json contains an invalid plugin registration.");
    }
    return plugin.name !== pluginName;
  });
}
marketplace.plugins.push(entry);
fs.writeFileSync(stagedFile, `${JSON.stringify(marketplace, null, 2)}\n`, { mode: 0o600 });
const descriptor = fs.openSync(stagedFile, "r");
try { fs.fsyncSync(descriptor); } finally { fs.closeSync(descriptor); }
process.stdout.write(marketplace.name);
JS
)"
  MARKETPLACE_EXPECTED="${TMP_ROOT}/marketplace.expected.json"
  cp -- "$MARKETPLACE_STAGE" "$MARKETPLACE_EXPECTED"
  chmod 600 "$MARKETPLACE_EXPECTED"
}

stage_expected_marketplace() {
  if [ -z "$MARKETPLACE_EXPECTED" ] || [ ! -f "$MARKETPLACE_EXPECTED" ] || [ -L "$MARKETPLACE_EXPECTED" ]; then
    echo "The reviewed marketplace plan is unavailable; refusing to trust CLI-mutated metadata." >&2
    return 1
  fi
  local staged_marketplace
  staged_marketplace="$(mktemp "${MARKETPLACE_ROOT}/.marketplace.json.stage.XXXXXXXX")"
  chmod 600 "$staged_marketplace"
  PENDING_STAGES+=("$staged_marketplace")
  node - "$MARKETPLACE_EXPECTED" "$staged_marketplace" <<'JS'
const fs = require("node:fs");
const [expectedFile, stagedFile] = process.argv.slice(2);
const expected = fs.readFileSync(expectedFile);
fs.writeFileSync(stagedFile, expected, { mode: 0o600 });
const descriptor = fs.openSync(stagedFile, "r");
try { fs.fsyncSync(descriptor); } finally { fs.closeSync(descriptor); }
JS
  printf '%s\n' "$staged_marketplace"
}

verify_expected_marketplace() {
  node - "$MARKETPLACE_EXPECTED" "$MARKETPLACE_FILE" <<'JS'
const fs = require("node:fs");
const [expectedFile, installedFile] = process.argv.slice(2);
const installedEntry = fs.lstatSync(installedFile);
if (!installedEntry.isFile() || installedEntry.isSymbolicLink()) process.exit(1);
const expected = fs.readFileSync(expectedFile);
const installed = fs.readFileSync(installedFile);
if (!expected.equals(installed)) process.exit(1);
JS
}

ensure_codex_plugin_enabled_config() {
  mkdir -p "$CODEX_ROOT"
  chmod 700 "$CODEX_ROOT"
  local staged_config
  staged_config="$(mktemp "${CODEX_ROOT}/.config.toml.stage.XXXXXXXX")"
  chmod 600 "$staged_config"
  PENDING_STAGES+=("$staged_config")

  node - "$CODEX_CONFIG_FILE" "$staged_config" "$PLUGIN_NAME" "$MARKETPLACE_NAME" <<'JS'
const fs = require("node:fs");

const configFile = process.argv[2];
const stagedFile = process.argv[3];
const pluginName = process.argv[4];
const marketplaceName = process.argv[5];
const pluginKey = `${pluginName}@${marketplaceName}`;
const header = `[plugins."${pluginKey}"]`;
let lines = [];
try {
  const rawConfig = fs.readFileSync(configFile);
  const configText = new TextDecoder("utf-8", { fatal: true }).decode(rawConfig).replace(/^\uFEFF/, "");
  if (configText.includes("\0") || configText.includes("\"\"\"") || configText.includes("'''")) {
    throw new Error("Existing Codex config uses unsupported complex TOML; refusing to modify it.");
  }
  lines = configText.split(/\r?\n/);
  if (lines.length && lines[lines.length - 1] === "") lines.pop();
} catch (error) {
  if (error.code !== "ENOENT") throw error;
}

function stripTomlComment(line) {
  let inBasicString = false;
  let inLiteralString = false;
  let escaped = false;
  for (let index = 0; index < line.length; index += 1) {
    const character = line[index];
    if (inBasicString) {
      if (escaped) escaped = false;
      else if (character === "\\") escaped = true;
      else if (character === '"') inBasicString = false;
      continue;
    }
    if (inLiteralString) {
      if (character === "'") inLiteralString = false;
      continue;
    }
    if (character === '#') return line.slice(0, index);
    if (character === '"') inBasicString = true;
    else if (character === "'") inLiteralString = true;
  }
  if (inBasicString || inLiteralString) {
    throw new Error("Existing Codex config contains an unterminated TOML string.");
  }
  return line;
}

function tableCode(line) {
  return stripTomlComment(line).trim();
}

function findTargetHeaderIndices(candidateLines) {
  const targetHeaders = new Set([header, `[plugins.'${pluginKey}']`]);
  const indices = [];
  candidateLines.forEach((line, index) => {
    const code = tableCode(line);
    if (targetHeaders.has(code)) {
      indices.push(index);
    } else if (code.startsWith("[") && code.includes(pluginKey)) {
      throw new Error("Existing Codex config has an ambiguous LuchiKey Image plugin table.");
    }
  });
  if (indices.length > 1) {
    throw new Error("Existing Codex config declares the LuchiKey Image plugin table more than once.");
  }
  return indices;
}

function findNextHeaderIndex(candidateLines, headerIndex) {
  for (let index = headerIndex + 1; index < candidateLines.length; index += 1) {
    const code = tableCode(candidateLines[index]);
    if (code.startsWith("[") && code.endsWith("]")) return index;
  }
  return candidateLines.length;
}

function findEnabledIndices(candidateLines, headerIndex, nextHeaderIndex) {
  const indices = [];
  for (let index = headerIndex + 1; index < nextHeaderIndex; index += 1) {
    const code = tableCode(candidateLines[index]);
    if (/^(?:enabled|"enabled"|'enabled')\s*=/.test(code)) indices.push(index);
  }
  if (indices.length > 1) {
    throw new Error("Existing Codex config declares the plugin enabled setting more than once.");
  }
  return indices;
}

let headerIndex = findTargetHeaderIndices(lines)[0] ?? -1;
if (headerIndex < 0) {
  if (lines.length && lines[lines.length - 1].trim()) lines.push("");
  lines.push(header, "enabled = true");
  headerIndex = lines.length - 2;
} else {
  const nextHeaderIndex = findNextHeaderIndex(lines, headerIndex);
  const enabledIndex = findEnabledIndices(lines, headerIndex, nextHeaderIndex)[0] ?? -1;
  if (enabledIndex >= 0) lines[enabledIndex] = "enabled = true";
  else lines.splice(headerIndex + 1, 0, "enabled = true");
}

const finalHeaderIndices = findTargetHeaderIndices(lines);
if (finalHeaderIndices.length !== 1) throw new Error("Generated Codex config is missing the plugin table.");
const finalHeaderIndex = finalHeaderIndices[0];
const finalEnabledIndices = findEnabledIndices(lines, finalHeaderIndex, findNextHeaderIndex(lines, finalHeaderIndex));
if (finalEnabledIndices.length !== 1 || tableCode(lines[finalEnabledIndices[0]]) !== "enabled = true") {
  throw new Error("Generated Codex config did not enable the plugin exactly once.");
}
const renderedConfig = `${lines.join("\n").replace(/\s+$/, "")}\n`;
fs.writeFileSync(stagedFile, renderedConfig, { mode: 0o600 });
const descriptor = fs.openSync(stagedFile, "r");
try { fs.fsyncSync(descriptor); } finally { fs.closeSync(descriptor); }
JS
  atomic_replace_file "$staged_config" "$CODEX_CONFIG_FILE"
}

configured_luchikey_api_key() {
  if [ -n "${LUCHIKEY_API_KEY:-}" ]; then
    printf '%s' "$LUCHIKEY_API_KEY"
    return 0
  fi
  if [ ! -f "$CONFIG_FILE" ]; then
    return 0
  fi
  node - "$CONFIG_FILE" <<'JS' 2>/dev/null || true
const fs = require("node:fs");
const configFile = process.argv[2];
try {
  const data = JSON.parse(fs.readFileSync(configFile, "utf8").replace(/^\uFEFF/, ""));
  process.stdout.write(String(data.api_key || data.luchikey_api_key || "").trim());
} catch {}
JS
}

write_luchikey_image_config() {
  local api_key="$1"
  local staged_config
  mkdir -p "$CONFIG_ROOT"
  chmod 700 "$CONFIG_ROOT"
  staged_config="$(mktemp "${CONFIG_ROOT}/.config.json.stage.XXXXXXXX")"
  chmod 600 "$staged_config"
  PENDING_STAGES+=("$staged_config")

  # The JavaScript is single-quoted so the API key is accepted only on stdin.
  # shellcheck disable=SC2016
  if ! printf '%s' "$api_key" | node -e '
const fs = require("node:fs");
const configFile = process.argv[1];
const stagedFile = process.argv[2];
const data = {
  api_key: fs.readFileSync(0, "utf8").trim(),
  base_url: "https://sub2api.luchikey.com",
  image_endpoint: "/v1/images/generations",
  image_edit_endpoint: "/v1/images/edits",
  image_model: "gpt-image-2",
  configured_at: new Date().toISOString().replace(/\.\d{3}Z$/, "Z"),
};
if (!data.api_key) throw new Error(`Refusing to write an empty API key to ${configFile}`);
fs.writeFileSync(stagedFile, `${JSON.stringify(data, null, 2)}\n`, { mode: 0o600 });
const descriptor = fs.openSync(stagedFile, "r");
try { fs.fsyncSync(descriptor); } finally { fs.closeSync(descriptor); }
' "$CONFIG_FILE" "$staged_config"; then
    rm -f "$staged_config"
    return 1
  fi
  atomic_replace_file "$staged_config" "$CONFIG_FILE"
  chmod 600 "$CONFIG_FILE"
}

validate_luchikey_image_api_key() {
  local api_key="$1"
  if [ -z "$api_key" ] || [[ "$api_key" =~ [[:cntrl:]] ]]; then
    return 1
  fi
  if ! command -v curl >/dev/null 2>&1; then
    echo "curl is unavailable, so the API key could not be verified." >&2
    return 2
  fi

  local escaped_api_key="${api_key//\\/\\\\}"
  escaped_api_key="${escaped_api_key//\"/\\\"}"
  local http_code=""
  local curl_ok=0
  if http_code="$({
    printf '%s\n' 'silent' 'show-error' 'output = "/dev/null"' 'write-out = "%{http_code}"' 'connect-timeout = 10' 'max-time = 20'
    printf 'header = "Authorization: Bearer %s"\n' "$escaped_api_key"
    printf '%s\n' 'header = "Accept: application/json"'
    printf 'header = "User-Agent: luchikey-image-installer/%s"\n' "$VERSION"
    printf '%s\n' 'proto = "=https"' 'url = "https://sub2api.luchikey.com/v1/models"'
  } | CURL_HOME="${TMP_ROOT}/curl-home" HOME="${TMP_ROOT}/curl-home" curl --config - 2>/dev/null)"; then
    curl_ok=1
  fi

  if [ "$curl_ok" -ne 1 ]; then
    echo "The LuchiKey API is unavailable, so the API key was not verified." >&2
    return 2
  fi
  case "$http_code" in
    2*) return 0 ;;
    401|403) return 1 ;;
    *)
      echo "The LuchiKey API could not verify the key right now (HTTP ${http_code:-unknown}); the key was not verified." >&2
      return 2
      ;;
  esac
}

read_luchikey_image_api_key() {
  local api_key=""
  READ_API_KEY=""
  echo ""
  echo "Paste your LuchiKey API key to finish setup."
  echo "The key is saved locally at: $CONFIG_FILE"
  if [ -r /dev/tty ]; then
    printf 'LUCHIKEY_API_KEY: ' > /dev/tty
    stty -echo < /dev/tty 2>/dev/null || true
    IFS= read -r api_key < /dev/tty || api_key=""
    stty echo < /dev/tty 2>/dev/null || true
    printf '\n' > /dev/tty
  fi
  READ_API_KEY="$api_key"
}

save_unverified_luchikey_api_key() {
  local api_key="$1"
  if ! write_luchikey_image_config "$api_key"; then
    echo "The API key could not be saved locally." >&2
    return 1
  fi
  KEY_STATE="unverified"
  echo "LuchiKey API key saved locally, but it was not verified because the API is unavailable." >&2
  return 0
}

ensure_luchikey_image_config() {
  local api_key validation_result attempt
  api_key="$(configured_luchikey_api_key)"
  if [ -n "$api_key" ]; then
    if validate_luchikey_image_api_key "$api_key"; then
      if ! write_luchikey_image_config "$api_key"; then
        return 1
      fi
      KEY_STATE="verified"
      echo "LuchiKey API key is saved and verified for the image plugin."
      return 0
    else
      validation_result=$?
    fi
    if [ "$validation_result" -eq 2 ]; then
      save_unverified_luchikey_api_key "$api_key"
      return $?
    fi
    echo "The existing LuchiKey API key is invalid or disabled. Please paste an active key." >&2
  fi

  attempt=1
  while [ "$attempt" -le 3 ]; do
    read_luchikey_image_api_key
    api_key="$READ_API_KEY"
    if [ -z "$api_key" ]; then
      echo "No API key was entered. The plugin is installed, but image generation will ask for LUCHIKEY_API_KEY later." >&2
      return 1
    fi

    if validate_luchikey_image_api_key "$api_key"; then
      if ! write_luchikey_image_config "$api_key"; then
        return 1
      fi
      KEY_STATE="verified"
      echo "LuchiKey API key saved and verified for the image plugin."
      return 0
    else
      validation_result=$?
    fi
    if [ "$validation_result" -eq 2 ]; then
      save_unverified_luchikey_api_key "$api_key"
      return $?
    fi

    echo "That LuchiKey API key was rejected. Please check that it is active and has access to image models." >&2
    attempt=$((attempt + 1))
  done

  echo "API key verification failed too many times. The plugin is installed, but image generation will ask for a valid LUCHIKEY_API_KEY later." >&2
  return 1
}

require_command node "Please install Node.js, then run this command again."
require_command curl "Please install curl, then run this command again."
require_command unzip "Please install unzip, then run this command again."
assert_install_paths_safe
acquire_install_lock

TMP_ROOT="$(mktemp -d "${TMPDIR:-/tmp}/luchikey-image-install.XXXXXXXX")"
chmod 700 "$TMP_ROOT"
mkdir "${TMP_ROOT}/curl-home"
chmod 700 "${TMP_ROOT}/curl-home"
ZIP_PATH="${TMP_ROOT}/luchikey-image-codex-plugin-${VERSION}.zip"
EXTRACT_ROOT="${TMP_ROOT}/extract"
mkdir "$EXTRACT_ROOT"
chmod 700 "$EXTRACT_ROOT"

download_release
verify_archive_checksum
validate_release_archive
unzip -qq "$ZIP_PATH" -d "$EXTRACT_ROOT"
EXTRACTED_PLUGIN="${EXTRACT_ROOT}/${PLUGIN_NAME}"
verify_installed_release_bytes "$EXTRACTED_PLUGIN"
secure_release_tree_permissions "$EXTRACTED_PLUGIN"

assert_install_paths_safe
mkdir -p "$PLUGIN_PARENT"
chmod 700 "$PLUGIN_PARENT"
PLUGIN_STAGE="$(stage_release_directory "$EXTRACTED_PLUGIN" "$PLUGIN_ROOT")"
PENDING_STAGES+=("$PLUGIN_STAGE")
prepare_marketplace_stage

CODEX_CACHE_PARENT="${CODEX_ROOT}/plugins/cache/${MARKETPLACE_NAME}/${PLUGIN_NAME}"
CODEX_CACHE_ROOT="${CODEX_CACHE_PARENT}/${VERSION}"
case "$CODEX_CACHE_ROOT" in
  "${CODEX_ROOT}/plugins/cache/${MARKETPLACE_NAME}/${PLUGIN_NAME}/${VERSION}") ;;
  *)
    echo "Refusing to write an unexpected Codex cache path: $CODEX_CACHE_ROOT" >&2
    exit 1
    ;;
esac
mkdir -p "$CODEX_ROOT"
assert_install_paths_safe
assert_safe_directory_chain "$CODEX_ROOT" "$CODEX_CACHE_PARENT"
mkdir -p "$CODEX_CACHE_PARENT"
assert_safe_directory_chain "$CODEX_ROOT" "$CODEX_CACHE_PARENT"
chmod 700 "$CODEX_ROOT" "${CODEX_ROOT}/plugins" "${CODEX_ROOT}/plugins/cache" \
  "${CODEX_ROOT}/plugins/cache/${MARKETPLACE_NAME}" "$CODEX_CACHE_PARENT"
CACHE_STAGE="$(stage_release_directory "$EXTRACTED_PLUGIN" "$CODEX_CACHE_ROOT")"
PENDING_STAGES+=("$CACHE_STAGE")

TRANSACTION_ACTIVE=1
assert_install_paths_safe
atomic_replace_directory "$PLUGIN_STAGE" "$PLUGIN_ROOT"
atomic_replace_file "$MARKETPLACE_STAGE" "$MARKETPLACE_FILE"
atomic_replace_directory "$CACHE_STAGE" "$CODEX_CACHE_ROOT"
ensure_codex_plugin_enabled_config

if ! verify_installed_release_bytes "$PLUGIN_ROOT" || ! verify_installed_release_bytes "$CODEX_CACHE_ROOT"; then
  echo "Initial installed plugin verification failed; restoring the previous installation." >&2
  exit 1
fi

assert_install_paths_safe
secure_release_tree_permissions "$CODEX_CACHE_ROOT"
ensure_codex_plugin_enabled_config

if ! verify_installed_release_bytes "$PLUGIN_ROOT" \
  || ! verify_installed_release_bytes "$CODEX_CACHE_ROOT" \
  || ! verify_expected_marketplace; then
  echo "Final installed plugin verification failed; restoring the previous installation." >&2
  exit 1
fi

finalize_transaction

if ensure_luchikey_image_config; then
  :
fi

echo ""
echo "LuchiKey Image was installed with the verified local Codex config fallback."
case "$KEY_STATE" in
  verified) echo "LuchiKey API key is saved locally and verified for the plugin." ;;
  unverified) echo "LuchiKey API key is saved locally but has not been verified." ;;
  *) echo "API key is not configured yet. Run this installer again and paste your LuchiKey API key." ;;
esac
echo "Setup is complete in this terminal. No Codex plugin page jump is required."
echo "Restart Codex, then ask: Generate a small yellow duck image in this conversation."
echo "Config: $CONFIG_FILE"
echo "Marketplace: $MARKETPLACE_FILE"
