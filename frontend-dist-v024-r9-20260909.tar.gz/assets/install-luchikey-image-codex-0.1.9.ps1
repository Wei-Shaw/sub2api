$ErrorActionPreference = "Stop"

$PluginName = "luchikey-image"
$Version = "0.1.9"
$ExpectedZipSha256 = "aa3d20cc6fa41207a282154371feaf96c8f45c2b6cb4638f098689c064945272"
$ZipUrl = "https://sub2api.luchikey.com/assets/luchikey-image-codex-plugin-0.1.9.zip"
$MaxZipBytes = 8 * 1024 * 1024
$MaxExpandedEntryBytes = 4 * 1024 * 1024
$MaxExpandedTotalBytes = 16 * 1024 * 1024
$ExpectedArchiveEntries = @(
  "luchikey-image/.codex-plugin/plugin.json",
  "luchikey-image/.mcp.json",
  "luchikey-image/README.md",
  "luchikey-image/image-endpoint-policy.mjs",
  "luchikey-image/image-errors.mjs",
  "luchikey-image/image-io.mjs",
  "luchikey-image/image-output-transaction.mjs",
  "luchikey-image/scripts/luchikey-image-mcp.mjs",
  "luchikey-image/scripts/output-transaction-smoke.mjs",
  "luchikey-image/scripts/smoke-mcp-client.mjs",
  "luchikey-image/scripts/smoke-mock-server.mjs",
  "luchikey-image/scripts/smoke-test.mjs",
  "luchikey-image/skills/luchikey-image/SKILL.md"
)

$HomeRoot = [Environment]::GetFolderPath([Environment+SpecialFolder]::UserProfile)
if ([string]::IsNullOrWhiteSpace($HomeRoot)) {
  throw "Could not resolve the current user's home directory."
}

$MarketplaceRoot = Join-Path $HomeRoot ".agents\plugins"
$MarketplaceFile = Join-Path $MarketplaceRoot "marketplace.json"
$PluginParent = Join-Path $HomeRoot "plugins"
$PluginRoot = Join-Path $PluginParent $PluginName
$ConfigRoot = Join-Path $HomeRoot ".luchikey-image"
$ConfigFile = Join-Path $ConfigRoot "config.json"
$CodexRoot = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $HomeRoot ".codex" }
$CodexConfigFile = Join-Path $CodexRoot "config.toml"
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

function Test-WindowsPlatform {
  return $env:OS -eq "Windows_NT"
}

function Get-NormalizedFullPath {
  param([Parameter(Mandatory = $true)][string]$Path)

  $FullPath = [System.IO.Path]::GetFullPath($Path)
  $PathRoot = [System.IO.Path]::GetPathRoot($FullPath)
  if ($FullPath.Length -gt $PathRoot.Length) {
    return $FullPath.TrimEnd([char[]]@(92, 47))
  }
  return $FullPath
}

function Assert-SafeDirectoryChain {
  param(
    [Parameter(Mandatory = $true)][string]$TrustRoot,
    [Parameter(Mandatory = $true)][string]$TargetDirectory
  )

  $TrustFull = Get-NormalizedFullPath -Path $TrustRoot
  $TargetFull = Get-NormalizedFullPath -Path $TargetDirectory
  if (![System.IO.Directory]::Exists($TrustFull)) {
    throw "The installer path trust root is unavailable: $TrustFull"
  }
  $Comparison = if (Test-WindowsPlatform) {
    [System.StringComparison]::OrdinalIgnoreCase
  } else {
    [System.StringComparison]::Ordinal
  }
  if ([string]::Equals($TargetFull, $TrustFull, $Comparison)) {
    return
  }
  $Prefix = $TrustFull
  if (!$Prefix.EndsWith([System.IO.Path]::DirectorySeparatorChar.ToString())) {
    $Prefix += [System.IO.Path]::DirectorySeparatorChar
  }
  if (!$TargetFull.StartsWith($Prefix, $Comparison)) {
    throw "Refusing an installer directory outside its declared root: $TargetFull"
  }

  $Relative = $TargetFull.Substring($Prefix.Length)
  $Components = $Relative.Split([char[]]@(92, 47), [System.StringSplitOptions]::RemoveEmptyEntries)
  $Current = $TrustFull
  foreach ($Component in $Components) {
    if ($Component -ceq "." -or $Component -ceq "..") {
      throw "Refusing an unsafe installer path component in: $TargetFull"
    }
    $Current = Join-Path $Current $Component
    if (![System.IO.File]::Exists($Current) -and ![System.IO.Directory]::Exists($Current)) {
      continue
    }
    $Item = Get-Item -LiteralPath $Current -Force
    if (($Item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
      throw "Refusing a reparse-point installer directory ancestor: $Current"
    }
    if (($Item.Attributes -band [System.IO.FileAttributes]::Directory) -eq 0) {
      throw "Refusing a non-directory installer path ancestor: $Current"
    }
  }
}

function Assert-InstallPathBoundaries {
  Assert-SafeDirectoryChain -TrustRoot $HomeRoot -TargetDirectory $MarketplaceRoot
  Assert-SafeDirectoryChain -TrustRoot $HomeRoot -TargetDirectory $PluginParent
  Assert-SafeDirectoryChain -TrustRoot $HomeRoot -TargetDirectory $ConfigRoot

  $HomeFull = Get-NormalizedFullPath -Path $HomeRoot
  $CodexFull = Get-NormalizedFullPath -Path $CodexRoot
  $Comparison = if (Test-WindowsPlatform) {
    [System.StringComparison]::OrdinalIgnoreCase
  } else {
    [System.StringComparison]::Ordinal
  }
  $HomePrefix = $HomeFull
  if (!$HomePrefix.EndsWith([System.IO.Path]::DirectorySeparatorChar.ToString())) {
    $HomePrefix += [System.IO.Path]::DirectorySeparatorChar
  }
  $CodexTrustRoot = if ([string]::Equals($CodexFull, $HomeFull, $Comparison) -or $CodexFull.StartsWith($HomePrefix, $Comparison)) {
    $HomeFull
  } else {
    [System.IO.Path]::GetPathRoot($CodexFull)
  }
  Assert-SafeDirectoryChain -TrustRoot $CodexTrustRoot -TargetDirectory $CodexFull
}

function Get-CurrentUserSid {
  if (!(Test-WindowsPlatform)) {
    return $null
  }
  return [System.Security.Principal.WindowsIdentity]::GetCurrent().User
}

function Set-PrivateDirectoryAcl {
  param([Parameter(Mandatory = $true)][string]$Path)

  if (!(Test-WindowsPlatform)) {
    return
  }

  $Sid = Get-CurrentUserSid
  $Security = New-Object System.Security.AccessControl.DirectorySecurity
  $Security.SetOwner($Sid)
  $Security.SetAccessRuleProtection($true, $false)
  $Rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
    $Sid,
    [System.Security.AccessControl.FileSystemRights]::FullControl,
    ([System.Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [System.Security.AccessControl.InheritanceFlags]::ObjectInherit),
    [System.Security.AccessControl.PropagationFlags]::None,
    [System.Security.AccessControl.AccessControlType]::Allow
  )
  $Security.AddAccessRule($Rule)
  Set-Acl -LiteralPath $Path -AclObject $Security
}

function Set-PrivateFileAcl {
  param([Parameter(Mandatory = $true)][string]$Path)

  if (!(Test-WindowsPlatform)) {
    return
  }

  $Sid = Get-CurrentUserSid
  $Security = New-Object System.Security.AccessControl.FileSecurity
  $Security.SetOwner($Sid)
  $Security.SetAccessRuleProtection($true, $false)
  $Rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
    $Sid,
    [System.Security.AccessControl.FileSystemRights]::FullControl,
    [System.Security.AccessControl.AccessControlType]::Allow
  )
  $Security.AddAccessRule($Rule)
  Set-Acl -LiteralPath $Path -AclObject $Security
}

function Assert-CurrentUserOnlyAcl {
  param(
    [Parameter(Mandatory = $true)][string]$Path,
    [Parameter(Mandatory = $true)][bool]$IsDirectory
  )

  if (!(Test-WindowsPlatform)) {
    return
  }

  $Sid = Get-CurrentUserSid
  $Acl = Get-Acl -LiteralPath $Path
  $Owner = $Acl.GetOwner([System.Security.Principal.SecurityIdentifier])
  if ($Owner.Value -ne $Sid.Value -or !$Acl.AreAccessRulesProtected) {
    throw "Private ACL verification failed for $Path."
  }

  $Rules = @($Acl.GetAccessRules($true, $true, [System.Security.Principal.SecurityIdentifier]))
  if ($Rules.Count -lt 1) {
    throw "Private ACL verification found no current-user access rule for $Path."
  }

  $FullControl = [System.Security.AccessControl.FileSystemRights]::FullControl
  $HasFullControl = $false
  foreach ($Rule in $Rules) {
    if ($Rule.IdentityReference.Value -ne $Sid.Value -or
        $Rule.AccessControlType -ne [System.Security.AccessControl.AccessControlType]::Allow -or
        $Rule.IsInherited) {
      throw "Private ACL verification found access for another principal on $Path."
    }
    if (($Rule.FileSystemRights -band $FullControl) -eq $FullControl) {
      $HasFullControl = $true
    }
  }

  if (!$HasFullControl) {
    throw "Private ACL verification did not find current-user full control for $Path."
  }

  if ($IsDirectory -and !(Test-Path -LiteralPath $Path -PathType Container)) {
    throw "Private directory ACL target is not a directory: $Path"
  }
  if (!$IsDirectory -and !(Test-Path -LiteralPath $Path -PathType Leaf)) {
    throw "Private file ACL target is not a file: $Path"
  }
}

function Ensure-PrivateDirectoryAcl {
  param([Parameter(Mandatory = $true)][string]$Path)

  if (!(Test-WindowsPlatform)) {
    return
  }
  try {
    Assert-CurrentUserOnlyAcl -Path $Path -IsDirectory $true
    return
  } catch {}
  Set-PrivateDirectoryAcl -Path $Path
  Assert-CurrentUserOnlyAcl -Path $Path -IsDirectory $true
}

function Ensure-PrivateFileAcl {
  param([Parameter(Mandatory = $true)][string]$Path)

  if (!(Test-WindowsPlatform)) {
    return
  }
  try {
    Assert-CurrentUserOnlyAcl -Path $Path -IsDirectory $false
    return
  } catch {}
  Set-PrivateFileAcl -Path $Path
  Assert-CurrentUserOnlyAcl -Path $Path -IsDirectory $false
}

function New-PrivateTempDirectory {
  $TempBase = [System.IO.Path]::GetFullPath([System.IO.Path]::GetTempPath())
  for ($Attempt = 0; $Attempt -lt 10; $Attempt += 1) {
    $Candidate = Join-Path $TempBase ("luchikey-image-installer-{0}" -f [Guid]::NewGuid().ToString("N"))
    if ([System.IO.Directory]::Exists($Candidate) -or [System.IO.File]::Exists($Candidate)) {
      continue
    }
    [System.IO.Directory]::CreateDirectory($Candidate) | Out-Null
    Ensure-PrivateDirectoryAcl -Path $Candidate
    return $Candidate
  }
  throw "Could not create a unique private installer directory."
}

function Remove-PrivateTempDirectory {
  param([Parameter(Mandatory = $true)][string]$Path)

  if (!(Test-Path -LiteralPath $Path)) {
    return
  }
  $TempBase = [System.IO.Path]::GetFullPath([System.IO.Path]::GetTempPath()).TrimEnd("\", "/")
  $Resolved = [System.IO.Path]::GetFullPath($Path)
  $Parent = [System.IO.Path]::GetDirectoryName($Resolved).TrimEnd("\", "/")
  $Leaf = [System.IO.Path]::GetFileName($Resolved)
  if ($Parent -ne $TempBase -or !$Leaf.StartsWith("luchikey-image-installer-", [System.StringComparison]::Ordinal)) {
    throw "Refusing to remove an unexpected temporary directory: $Resolved"
  }
  Remove-Item -LiteralPath $Resolved -Recurse -Force
}

function Get-StableInstallLockSuffix {
  $Hasher = [System.Security.Cryptography.SHA256]::Create()
  try {
    $HomeBytes = [System.Text.Encoding]::UTF8.GetBytes($HomeRoot.ToLowerInvariant())
    $Digest = $Hasher.ComputeHash($HomeBytes)
    return ([System.BitConverter]::ToString($Digest)).Replace("-", "").Substring(0, 24)
  } finally {
    $Hasher.Dispose()
  }
}

function Enter-LuchiKeyImageInstallLock {
  $LockRoot = Join-Path $ConfigRoot ".locks"
  [System.IO.Directory]::CreateDirectory($ConfigRoot) | Out-Null
  Ensure-PrivateDirectoryAcl -Path $ConfigRoot
  [System.IO.Directory]::CreateDirectory($LockRoot) | Out-Null
  Ensure-PrivateDirectoryAcl -Path $LockRoot
  $LockPath = Join-Path $LockRoot ("install-{0}.lock" -f (Get-StableInstallLockSuffix))
  try {
    $Stream = New-Object System.IO.FileStream(
      $LockPath,
      [System.IO.FileMode]::OpenOrCreate,
      [System.IO.FileAccess]::ReadWrite,
      [System.IO.FileShare]::None
    )
  } catch [System.IO.IOException] {
    throw "Another LuchiKey Image installation is already running for this user."
  }
  return [pscustomobject]@{ Stream = $Stream; Path = $LockPath }
}

function Exit-LuchiKeyImageInstallLock {
  param([Parameter(Mandatory = $true)]$Lock)

  $Lock.Stream.Dispose()
}

function Receive-BoundedHttpsFile {
  param(
    [Parameter(Mandatory = $true)][string]$Uri,
    [Parameter(Mandatory = $true)][string]$Destination,
    [Parameter(Mandatory = $true)][long]$MaximumBytes
  )

  $PinnedUri = New-Object System.Uri($ZipUrl)
  $RequestedUri = New-Object System.Uri($Uri)
  if ($RequestedUri.AbsoluteUri -cne $PinnedUri.AbsoluteUri -or
      $RequestedUri.Scheme -cne "https" -or
      $RequestedUri.Host -cne "sub2api.luchikey.com" -or
      !$RequestedUri.IsDefaultPort -or
      $RequestedUri.Query) {
    throw "Installer download URL is not the pinned same-origin HTTPS asset."
  }

  Add-Type -AssemblyName System.Net.Http
  $Handler = New-Object System.Net.Http.HttpClientHandler
  $Handler.AllowAutoRedirect = $false
  $Client = New-Object System.Net.Http.HttpClient($Handler)
  $Client.Timeout = [System.Threading.Timeout]::InfiniteTimeSpan
  $Deadline = New-Object System.Threading.CancellationTokenSource
  $Deadline.CancelAfter([TimeSpan]::FromSeconds(30))
  $Request = New-Object System.Net.Http.HttpRequestMessage([System.Net.Http.HttpMethod]::Get, $RequestedUri)
  $Request.Headers.UserAgent.ParseAdd("luchikey-image-installer/$Version")
  $Response = $null
  $InputStream = $null
  $OutputStream = $null

  try {
    $Response = $Client.SendAsync(
      $Request,
      [System.Net.Http.HttpCompletionOption]::ResponseHeadersRead,
      $Deadline.Token
    ).GetAwaiter().GetResult()
    $Status = [int]$Response.StatusCode
    if ($Status -lt 200 -or $Status -ge 300) {
      throw "Plugin download returned HTTP $Status."
    }
    if ($Response.Content.Headers.ContentLength.HasValue -and
        $Response.Content.Headers.ContentLength.Value -gt $MaximumBytes) {
      throw "Plugin archive exceeds the $MaximumBytes byte download limit."
    }

    $InputStream = $Response.Content.ReadAsStreamAsync().GetAwaiter().GetResult()
    if ($InputStream.CanTimeout) {
      $InputStream.ReadTimeout = 30000
    }
    $OutputStream = New-Object System.IO.FileStream(
      $Destination,
      [System.IO.FileMode]::CreateNew,
      [System.IO.FileAccess]::Write,
      [System.IO.FileShare]::None
    )
    $Buffer = New-Object byte[] 65536
    [long]$Downloaded = 0
    while (($Read = $InputStream.ReadAsync($Buffer, 0, $Buffer.Length, $Deadline.Token).GetAwaiter().GetResult()) -gt 0) {
      if ($Downloaded -gt ($MaximumBytes - $Read)) {
        throw "Plugin archive exceeded the $MaximumBytes byte download limit."
      }
      $OutputStream.Write($Buffer, 0, $Read)
      $Downloaded += $Read
    }
    $OutputStream.Flush($true)
    if ($Downloaded -le 0) {
      throw "Plugin download returned an empty archive."
    }
  } finally {
    if ($OutputStream) { $OutputStream.Dispose() }
    if ($InputStream) { $InputStream.Dispose() }
    if ($Response) { $Response.Dispose() }
    $Request.Dispose()
    $Deadline.Dispose()
    $Client.Dispose()
    $Handler.Dispose()
  }
}

function Assert-PinnedArchiveHash {
  param([Parameter(Mandatory = $true)][string]$ZipPath)

  $Actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $ZipPath).Hash.ToLowerInvariant()
  if ($Actual -cne $ExpectedZipSha256) {
    throw "Downloaded plugin checksum mismatch. Expected $ExpectedZipSha256 but got $Actual."
  }
}

function Get-UnsignedExternalAttributes {
  param([Parameter(Mandatory = $true)][int]$Attributes)

  return [System.BitConverter]::ToUInt32([System.BitConverter]::GetBytes($Attributes), 0)
}

function Read-BoundedZipEntryBytes {
  param(
    [Parameter(Mandatory = $true)][System.IO.Compression.ZipArchiveEntry]$Entry,
    [Parameter(Mandatory = $true)][long]$MaximumBytes
  )

  $InputStream = $Entry.Open()
  $OutputStream = New-Object System.IO.MemoryStream
  try {
    $Buffer = New-Object byte[] 65536
    [long]$Total = 0
    while (($Read = $InputStream.Read($Buffer, 0, $Buffer.Length)) -gt 0) {
      if ($Total -gt ($MaximumBytes - $Read)) {
        throw "Archive entry $($Entry.FullName) exceeded its expanded size limit."
      }
      $OutputStream.Write($Buffer, 0, $Read)
      $Total += $Read
    }
    if ($Total -ne $Entry.Length) {
      throw "Archive entry $($Entry.FullName) expanded to an unexpected length."
    }
    return $OutputStream.ToArray()
  } finally {
    $OutputStream.Dispose()
    $InputStream.Dispose()
  }
}

function Expand-ValidatedPluginArchive {
  param(
    [Parameter(Mandatory = $true)][string]$ZipPath,
    [Parameter(Mandatory = $true)][string]$DestinationRoot
  )

  Add-Type -AssemblyName System.IO.Compression
  $Expected = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
  foreach ($Name in $ExpectedArchiveEntries) {
    if (!$Expected.Add($Name)) {
      throw "Installer archive allowlist contains a duplicate entry: $Name"
    }
  }
  if ($Expected.Count -ne 13) {
    throw "Installer archive allowlist must contain exactly 13 files."
  }

  $ZipStream = New-Object System.IO.FileStream(
    $ZipPath,
    [System.IO.FileMode]::Open,
    [System.IO.FileAccess]::Read,
    [System.IO.FileShare]::None
  )
  $Archive = $null

  try {
    if ($ZipStream.Length -le 0 -or $ZipStream.Length -gt $MaxZipBytes) {
      throw "Plugin archive is empty or exceeds the fixed download size limit."
    }
    $Hasher = [System.Security.Cryptography.SHA256]::Create()
    try {
      $OpenHandleHash = ([System.BitConverter]::ToString($Hasher.ComputeHash($ZipStream))).Replace("-", "").ToLowerInvariant()
    } finally {
      $Hasher.Dispose()
    }
    if ($OpenHandleHash -cne $ExpectedZipSha256) {
      throw "Plugin archive checksum changed before validation."
    }
    $ZipStream.Position = 0
    $Archive = New-Object System.IO.Compression.ZipArchive(
      $ZipStream,
      [System.IO.Compression.ZipArchiveMode]::Read,
      $true
    )

    if ($Archive.Entries.Count -ne $Expected.Count) {
      throw "Plugin archive must contain exactly $($Expected.Count) regular files."
    }

    $Seen = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
    $ManifestEntry = $null
    [long]$DeclaredTotal = 0
    foreach ($Entry in $Archive.Entries) {
      $Name = [string]$Entry.FullName
      if ([string]::IsNullOrWhiteSpace($Name) -or
          $Name.EndsWith("/", [System.StringComparison]::Ordinal) -or
          $Name.Contains("\") -or
          [System.IO.Path]::IsPathRooted($Name) -or
          $Name.Split("/") -contains ".." -or
          $Name.Split("/") -contains "." -or
          !$Expected.Contains($Name)) {
        throw "Plugin archive contains a disallowed path: $Name"
      }
      if (!$Seen.Add($Name)) {
        throw "Plugin archive contains a duplicate entry: $Name"
      }

      $External = Get-UnsignedExternalAttributes -Attributes $Entry.ExternalAttributes
      $UnixMode = ($External -shr 16) -band 0xffff
      $UnixFileType = $UnixMode -band 0xf000
      $DosAttributes = $External -band 0xffff
      if ($UnixFileType -ne 0x8000 -or ($DosAttributes -band 0x10) -ne 0) {
        throw "Plugin archive entry is not a regular file: $Name"
      }
      if ($Entry.Length -lt 0 -or $Entry.Length -gt $MaxExpandedEntryBytes) {
        throw "Plugin archive entry exceeds its expanded size limit: $Name"
      }
      if ($DeclaredTotal -gt ($MaxExpandedTotalBytes - $Entry.Length)) {
        throw "Plugin archive exceeds the aggregate expanded size limit."
      }
      $DeclaredTotal += $Entry.Length
      if ($Name -ceq "luchikey-image/.codex-plugin/plugin.json") {
        $ManifestEntry = $Entry
      }
    }

    if (!$Expected.SetEquals($Seen) -or !$ManifestEntry) {
      throw "Plugin archive entries do not exactly match the fixed release allowlist."
    }

    $ManifestBytes = Read-BoundedZipEntryBytes -Entry $ManifestEntry -MaximumBytes $MaxExpandedEntryBytes
    $StrictUtf8 = New-Object System.Text.UTF8Encoding($false, $true)
    try {
      $ManifestJson = $StrictUtf8.GetString($ManifestBytes) | ConvertFrom-Json
    } catch {
      throw "Plugin archive has an invalid UTF-8 JSON manifest."
    }
    if ([string]$ManifestJson.name -cne $PluginName -or [string]$ManifestJson.version -cne $Version) {
      throw "Plugin manifest identity does not match $PluginName version $Version."
    }

    if ([System.IO.Directory]::Exists($DestinationRoot) -or [System.IO.File]::Exists($DestinationRoot)) {
      throw "Validated extraction destination already exists."
    }
    [System.IO.Directory]::CreateDirectory($DestinationRoot) | Out-Null
    $DestinationFull = [System.IO.Path]::GetFullPath($DestinationRoot).TrimEnd("\", "/")
    $DestinationPrefix = $DestinationFull + [System.IO.Path]::DirectorySeparatorChar
    [long]$ExtractedTotal = 0

    foreach ($Entry in $Archive.Entries) {
      $RelativeName = $Entry.FullName.Substring(("$PluginName/").Length)
      $RelativePath = $RelativeName.Replace("/", [System.IO.Path]::DirectorySeparatorChar)
      $Target = [System.IO.Path]::GetFullPath((Join-Path $DestinationFull $RelativePath))
      if (!$Target.StartsWith($DestinationPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Plugin archive entry escaped the validated extraction root."
      }
      $TargetParent = [System.IO.Path]::GetDirectoryName($Target)
      [System.IO.Directory]::CreateDirectory($TargetParent) | Out-Null

      $InputStream = $Entry.Open()
      $OutputStream = New-Object System.IO.FileStream(
        $Target,
        [System.IO.FileMode]::CreateNew,
        [System.IO.FileAccess]::Write,
        [System.IO.FileShare]::None
      )
      try {
        $Buffer = New-Object byte[] 65536
        [long]$EntryTotal = 0
        while (($Read = $InputStream.Read($Buffer, 0, $Buffer.Length)) -gt 0) {
          if ($EntryTotal -gt ($MaxExpandedEntryBytes - $Read) -or
              $ExtractedTotal -gt ($MaxExpandedTotalBytes - $Read)) {
            throw "Plugin archive exceeded an expanded size limit during extraction."
          }
          $OutputStream.Write($Buffer, 0, $Read)
          $EntryTotal += $Read
          $ExtractedTotal += $Read
        }
        $OutputStream.Flush($true)
        if ($EntryTotal -ne $Entry.Length) {
          throw "Plugin archive entry expanded to an unexpected length: $($Entry.FullName)"
        }
      } finally {
        $OutputStream.Dispose()
        $InputStream.Dispose()
      }
    }
  } finally {
    if ($Archive) { $Archive.Dispose() }
    $ZipStream.Dispose()
  }

  if (!(Test-InstalledReleaseBytes -InstalledRoot $DestinationRoot -ValidatedRoot $DestinationRoot)) {
    throw "Validated extraction did not produce the exact fixed plugin release."
  }
  return $DestinationRoot
}

function Get-RelativePluginEntries {
  $Relative = @()
  $Prefix = "$PluginName/"
  foreach ($Name in $ExpectedArchiveEntries) {
    $Relative += $Name.Substring($Prefix.Length)
  }
  return $Relative
}

function Test-InstalledReleaseBytes {
  param(
    [Parameter(Mandatory = $true)][string]$InstalledRoot,
    [Parameter(Mandatory = $true)][Alias("ExpectedRoot", "ReferenceRoot")][string]$ValidatedRoot
  )

  try {
    if (!(Test-Path -LiteralPath $InstalledRoot -PathType Container) -or
        !(Test-Path -LiteralPath $ValidatedRoot -PathType Container)) {
      return $false
    }

    $ExpectedFiles = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
    $ExpectedDirectories = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
    foreach ($Relative in Get-RelativePluginEntries) {
      $ExpectedFiles.Add($Relative) | Out-Null
      $Parts = $Relative.Split("/")
      if ($Parts.Length -gt 1) {
        for ($Index = 1; $Index -lt $Parts.Length; $Index += 1) {
          $ExpectedDirectories.Add(($Parts[0..($Index - 1)] -join "/")) | Out-Null
        }
      }
    }

    $InstalledFull = [System.IO.Path]::GetFullPath($InstalledRoot).TrimEnd("\", "/")
    $InstalledFiles = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
    foreach ($Item in Get-ChildItem -LiteralPath $InstalledFull -Recurse -Force) {
      $Relative = $Item.FullName.Substring($InstalledFull.Length).TrimStart("\", "/").Replace("\", "/")
      if (($Item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
        return $false
      }
      if ($Item.PSIsContainer) {
        if (!$ExpectedDirectories.Contains($Relative)) {
          return $false
        }
        continue
      }
      if (!$ExpectedFiles.Contains($Relative) -or !$InstalledFiles.Add($Relative)) {
        return $false
      }

      $ValidatedPath = Join-Path $ValidatedRoot $Relative.Replace("/", [System.IO.Path]::DirectorySeparatorChar)
      if (!(Test-Path -LiteralPath $ValidatedPath -PathType Leaf) -or $Item.Length -ne (Get-Item -LiteralPath $ValidatedPath).Length) {
        return $false
      }
      $InstalledHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $Item.FullName).Hash
      $ValidatedHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $ValidatedPath).Hash
      if ($InstalledHash -cne $ValidatedHash) {
        return $false
      }
    }

    if (!$ExpectedFiles.SetEquals($InstalledFiles)) {
      return $false
    }
    $InstalledManifestPath = Join-Path $InstalledRoot ".codex-plugin\plugin.json"
    $InstalledManifest = Get-Content -LiteralPath $InstalledManifestPath -Raw | ConvertFrom-Json
    return [string]$InstalledManifest.name -ceq $PluginName -and [string]$InstalledManifest.version -ceq $Version
  } catch {
    return $false
  }
}

function Get-UniqueSiblingPath {
  param(
    [Parameter(Mandatory = $true)][string]$TargetPath,
    [Parameter(Mandatory = $true)][ValidateSet("stage", "backup", "rollback")][string]$Kind
  )

  $FullTarget = [System.IO.Path]::GetFullPath($TargetPath)
  $Parent = [System.IO.Path]::GetDirectoryName($FullTarget)
  $Leaf = [System.IO.Path]::GetFileName($FullTarget)
  return Join-Path $Parent (".{0}.luchikey-image-{1}-{2}" -f $Leaf, $Kind, [Guid]::NewGuid().ToString("N"))
}

function Test-PathExists {
  param([Parameter(Mandatory = $true)][string]$Path)
  return [System.IO.File]::Exists($Path) -or [System.IO.Directory]::Exists($Path)
}

function Move-PathAtomically {
  param(
    [Parameter(Mandatory = $true)][string]$Source,
    [Parameter(Mandatory = $true)][string]$Destination
  )

  if ([System.IO.Directory]::Exists($Source)) {
    [System.IO.Directory]::Move($Source, $Destination)
    return
  }
  if ([System.IO.File]::Exists($Source)) {
    [System.IO.File]::Move($Source, $Destination)
    return
  }
  throw "Atomic move source does not exist: $Source"
}

function Remove-InstallerTemporaryPath {
  param([Parameter(Mandatory = $true)][string]$Path)

  if ([System.IO.Directory]::Exists($Path)) {
    Remove-Item -LiteralPath $Path -Recurse -Force
  } elseif ([System.IO.File]::Exists($Path)) {
    Remove-Item -LiteralPath $Path -Force
  }
}

function Assert-SafeReplacementTarget {
  param(
    [Parameter(Mandatory = $true)][string]$Target,
    [Parameter(Mandatory = $true)][bool]$StageIsDirectory
  )

  if (!(Test-PathExists -Path $Target)) {
    return
  }
  $TargetIsDirectory = [System.IO.Directory]::Exists($Target)
  if ($TargetIsDirectory -ne $StageIsDirectory) {
    throw "Refusing to replace an install target whose file type changed: $Target"
  }
  $RootItem = Get-Item -LiteralPath $Target -Force
  if (($RootItem.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
    throw "Refusing to replace a reparse-point install target: $Target"
  }
  if (!$TargetIsDirectory) {
    return
  }

  $Pending = New-Object 'System.Collections.Generic.Stack[string]'
  $Pending.Push([System.IO.Path]::GetFullPath($Target))
  $Scanned = 0
  while ($Pending.Count -gt 0) {
    $CurrentDirectory = $Pending.Pop()
    $Enumerator = [System.IO.Directory]::EnumerateFileSystemEntries($CurrentDirectory).GetEnumerator()
    try {
      while ($Enumerator.MoveNext()) {
        $Child = [string]$Enumerator.Current
        $Scanned += 1
        if ($Scanned -gt 1024) {
          throw "Refusing to replace an unexpectedly large existing plugin tree: $Target"
        }
        $Attributes = [System.IO.File]::GetAttributes($Child)
        if (($Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
          throw "Refusing to replace a plugin tree that contains a reparse point: $Child"
        }
        if (($Attributes -band [System.IO.FileAttributes]::Directory) -ne 0) {
          $Pending.Push($Child)
        }
      }
    } finally {
      if ($Enumerator -is [System.IDisposable]) {
        $Enumerator.Dispose()
      }
    }
  }
}

function Invoke-AtomicPathTransaction {
  param(
    [Parameter(Mandatory = $true)][object[]]$Changes,
    [Parameter(Mandatory = $true)][scriptblock]$PostCommitValidation
  )

  $Records = New-Object System.Collections.ArrayList
  foreach ($Change in $Changes) {
    $Target = [System.IO.Path]::GetFullPath([string]$Change.Target)
    $Stage = [System.IO.Path]::GetFullPath([string]$Change.Stage)
    if (!(Test-PathExists -Path $Stage)) {
      throw "Install staging path is missing: $Stage"
    }
    if ([System.IO.Path]::GetDirectoryName($Target) -ne [System.IO.Path]::GetDirectoryName($Stage)) {
      throw "Install staging path must share its target parent: $Target"
    }
    Assert-SafeReplacementTarget -Target $Target -StageIsDirectory ([System.IO.Directory]::Exists($Stage))
  }

  try {
    foreach ($Change in $Changes) {
      $Target = [System.IO.Path]::GetFullPath([string]$Change.Target)
      $Stage = [System.IO.Path]::GetFullPath([string]$Change.Stage)
      $Backup = Get-UniqueSiblingPath -TargetPath $Target -Kind "backup"
      $Record = [pscustomobject]@{
        Target = $Target
        Stage = $Stage
        Backup = $Backup
        HadOriginal = (Test-PathExists -Path $Target)
        Applied = $false
      }
      $Records.Add($Record) | Out-Null
      if ($Record.HadOriginal) {
        Move-PathAtomically -Source $Target -Destination $Backup
      }
      Move-PathAtomically -Source $Stage -Destination $Target
      $Record.Applied = $true
    }

    & $PostCommitValidation
  } catch {
    $PrimaryError = $_.Exception.Message
    $RollbackErrors = New-Object System.Collections.Generic.List[string]
    for ($Index = $Records.Count - 1; $Index -ge 0; $Index -= 1) {
      $Record = $Records[$Index]
      try {
        $Displaced = $null
        if ($Record.Applied -and (Test-PathExists -Path $Record.Target)) {
          $Displaced = Get-UniqueSiblingPath -TargetPath $Record.Target -Kind "rollback"
          Move-PathAtomically -Source $Record.Target -Destination $Displaced
        }
        if ($Record.HadOriginal -and (Test-PathExists -Path $Record.Backup)) {
          Move-PathAtomically -Source $Record.Backup -Destination $Record.Target
        }
        if ($Displaced -and (Test-PathExists -Path $Displaced)) {
          Remove-InstallerTemporaryPath -Path $Displaced
        }
      } catch {
        $RollbackErrors.Add($_.Exception.Message)
      }
    }
    foreach ($Change in $Changes) {
      if (Test-PathExists -Path ([string]$Change.Stage)) {
        Remove-InstallerTemporaryPath -Path ([string]$Change.Stage)
      }
    }
    if ($RollbackErrors.Count -gt 0) {
      throw "$PrimaryError Rollback was incomplete: $($RollbackErrors -join '; ')"
    }
    throw $PrimaryError
  }

  foreach ($Record in $Records) {
    if ($Record.HadOriginal -and (Test-PathExists -Path $Record.Backup)) {
      try {
        Remove-InstallerTemporaryPath -Path $Record.Backup
      } catch {
        Write-Warning "Installed release is verified, but an old backup could not be removed: $($Record.Backup)"
      }
    }
  }
}

function Write-AtomicFile {
  param(
    [Parameter(Mandatory = $true)][string]$Path,
    [Parameter(Mandatory = $true)][byte[]]$Bytes,
    [switch]$PrivateWindowsAcl
  )

  $Target = [System.IO.Path]::GetFullPath($Path)
  $Parent = [System.IO.Path]::GetDirectoryName($Target)
  [System.IO.Directory]::CreateDirectory($Parent) | Out-Null
  $Stage = Get-UniqueSiblingPath -TargetPath $Target -Kind "stage"
  $Backup = Get-UniqueSiblingPath -TargetPath $Target -Kind "backup"
  $HadOriginal = Test-PathExists -Path $Target
  $Applied = $false

  Assert-SafeReplacementTarget -Target $Target -StageIsDirectory $false

  try {
    $Stream = New-Object System.IO.FileStream(
      $Stage,
      [System.IO.FileMode]::CreateNew,
      [System.IO.FileAccess]::Write,
      [System.IO.FileShare]::None
    )
    try {
      $Stream.Write($Bytes, 0, $Bytes.Length)
      $Stream.Flush($true)
    } finally {
      $Stream.Dispose()
    }
    if ($PrivateWindowsAcl) {
      Ensure-PrivateFileAcl -Path $Stage
    }

    if ($HadOriginal) {
      Move-PathAtomically -Source $Target -Destination $Backup
      if ($PrivateWindowsAcl) {
        Ensure-PrivateFileAcl -Path $Backup
      }
    }
    Move-PathAtomically -Source $Stage -Destination $Target
    $Applied = $true
    if ($PrivateWindowsAcl) {
      Ensure-PrivateFileAcl -Path $Target
    }
    if ($HadOriginal -and (Test-PathExists -Path $Backup)) {
      Remove-InstallerTemporaryPath -Path $Backup
    }
  } catch {
    $PrimaryError = $_.Exception.Message
    try {
      if ($Applied -and (Test-PathExists -Path $Target)) {
        $Displaced = Get-UniqueSiblingPath -TargetPath $Target -Kind "rollback"
        Move-PathAtomically -Source $Target -Destination $Displaced
        Remove-InstallerTemporaryPath -Path $Displaced
      }
      if ($HadOriginal -and (Test-PathExists -Path $Backup)) {
        Move-PathAtomically -Source $Backup -Destination $Target
      }
    } catch {
      throw "$PrimaryError Credential file rollback was incomplete: $($_.Exception.Message)"
    } finally {
      if (Test-PathExists -Path $Stage) {
        Remove-InstallerTemporaryPath -Path $Stage
      }
    }
    throw $PrimaryError
  }
}

function Set-PrivateCredentialFile {
  param(
    [Parameter(Mandatory = $true)][string]$Path,
    [Parameter(Mandatory = $true)][Alias("Content", "JsonText")][string]$Json
  )

  $Parent = [System.IO.Path]::GetDirectoryName([System.IO.Path]::GetFullPath($Path))
  [System.IO.Directory]::CreateDirectory($Parent) | Out-Null
  if (Test-WindowsPlatform) {
    Ensure-PrivateDirectoryAcl -Path $Parent
  }
  $Bytes = $Utf8NoBom.GetBytes($Json)
  Write-AtomicFile -Path $Path -Bytes $Bytes -PrivateWindowsAcl
  Ensure-PrivateFileAcl -Path $Path
}

function Copy-ValidatedPluginTree {
  param(
    [Parameter(Mandatory = $true)][string]$SourceRoot,
    [Parameter(Mandatory = $true)][string]$DestinationRoot
  )

  [System.IO.Directory]::CreateDirectory($DestinationRoot) | Out-Null
  foreach ($Relative in Get-RelativePluginEntries) {
    $PlatformRelative = $Relative.Replace("/", [System.IO.Path]::DirectorySeparatorChar)
    $Source = Join-Path $SourceRoot $PlatformRelative
    $Destination = Join-Path $DestinationRoot $PlatformRelative
    [System.IO.Directory]::CreateDirectory([System.IO.Path]::GetDirectoryName($Destination)) | Out-Null
    [System.IO.File]::Copy($Source, $Destination, $false)
  }
  if (!(Test-InstalledReleaseBytes -InstalledRoot $DestinationRoot -ValidatedRoot $SourceRoot)) {
    throw "Plugin staging bytes do not match the validated release."
  }
}

function Get-MarketplacePlan {
  param([string]$RequiredMarketplaceName = "")

  $MarketplaceName = if ($RequiredMarketplaceName) { $RequiredMarketplaceName } else { "personal" }
  $Marketplace = [ordered]@{
    name = $MarketplaceName
    interface = [ordered]@{ displayName = "Personal" }
    plugins = @()
  }
  $Plugins = @()
  if (Test-Path -LiteralPath $MarketplaceFile) {
    try {
      $Existing = Get-Content -LiteralPath $MarketplaceFile -Raw | ConvertFrom-Json
      if (!$Existing -or $Existing -isnot [System.Management.Automation.PSCustomObject]) {
        throw "marketplace root is not an object"
      }
      $ExistingProperties = @($Existing.PSObject.Properties.Name)
      if ($ExistingProperties -notcontains "name" -or $Existing.name -isnot [string] -or
          $ExistingProperties -notcontains "plugins" -or $Existing.plugins -isnot [Array]) {
        throw "marketplace schema is missing name or plugins"
      }
      $ExistingName = [string]$Existing.name
      if ($ExistingName -notmatch '^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$') {
        throw "marketplace name is unsafe"
      }
      if ($RequiredMarketplaceName -and $ExistingName -cne $RequiredMarketplaceName) {
        throw "marketplace name changed while installation was in progress"
      }
      if (!$RequiredMarketplaceName) {
        $MarketplaceName = $ExistingName
      }

      $Marketplace = [ordered]@{}
      foreach ($Property in $Existing.PSObject.Properties) {
        $Marketplace[$Property.Name] = $Property.Value
      }
      $Marketplace["name"] = $MarketplaceName
      if ($ExistingProperties -contains "interface") {
        if (!$Existing.interface -or $Existing.interface -isnot [System.Management.Automation.PSCustomObject]) {
          throw "marketplace interface is not an object"
        }
        $Interface = [ordered]@{}
        foreach ($Property in $Existing.interface.PSObject.Properties) {
          $Interface[$Property.Name] = $Property.Value
        }
        if ($Interface.Contains("displayName")) {
          if ($Interface["displayName"] -isnot [string]) {
            throw "marketplace display name is invalid"
          }
        } else {
          $Interface["displayName"] = "Personal"
        }
        $Marketplace["interface"] = $Interface
      } else {
        $Marketplace["interface"] = [ordered]@{ displayName = "Personal" }
      }
      foreach ($Plugin in @($Existing.plugins)) {
        if (!$Plugin -or $Plugin -isnot [System.Management.Automation.PSCustomObject] -or
            @($Plugin.PSObject.Properties.Name) -notcontains "name" -or $Plugin.name -isnot [string] -or
            [string]::IsNullOrWhiteSpace([string]$Plugin.name)) {
          throw "marketplace contains an invalid plugin entry"
        }
        if ([string]$Plugin.name -cne $PluginName) {
          $Plugins += $Plugin
        }
      }
    } catch {
      throw "Existing marketplace.json could not be parsed or validated; refusing to replace it."
    }
  }
  if ($MarketplaceName -notmatch '^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$') {
    throw "Marketplace name is unsafe."
  }

  $Plugins += [ordered]@{
    name = $PluginName
    source = [ordered]@{
      source = "local"
      path = "./plugins/$PluginName"
    }
    policy = [ordered]@{
      installation = "AVAILABLE"
      authentication = "ON_USE"
    }
    category = "Productivity"
  }
  $Marketplace["plugins"] = @($Plugins)
  return [pscustomobject]@{
    Name = $MarketplaceName
    Json = (($Marketplace | ConvertTo-Json -Depth 8) + [Environment]::NewLine)
  }
}

function Get-TomlCode {
  param([Parameter(Mandatory = $true)][AllowEmptyString()][string]$Line)

  $InBasicString = $false
  $InLiteralString = $false
  $Escaped = $false
  for ($Index = 0; $Index -lt $Line.Length; $Index += 1) {
    $Character = $Line[$Index]
    if ($InBasicString) {
      if ($Escaped) {
        $Escaped = $false
      } elseif ($Character -ceq "\") {
        $Escaped = $true
      } elseif ($Character -ceq '"') {
        $InBasicString = $false
      }
      continue
    }
    if ($InLiteralString) {
      if ($Character -ceq "'") {
        $InLiteralString = $false
      }
      continue
    }
    if ($Character -ceq '#') {
      return $Line.Substring(0, $Index).Trim()
    }
    if ($Character -ceq '"') {
      $InBasicString = $true
    } elseif ($Character -ceq "'") {
      $InLiteralString = $true
    }
  }
  if ($InBasicString -or $InLiteralString) {
    throw "Existing Codex config contains an unterminated TOML string."
  }
  return $Line.Trim()
}

function Get-CodexPluginHeaderCodes {
  param([Parameter(Mandatory = $true)][string]$MarketplaceName)

  $PluginKey = "$PluginName@$MarketplaceName"
  return @("[plugins.`"$PluginKey`"]", "[plugins.'$PluginKey']")
}

function Test-CodexPluginConfigText {
  param(
    [Parameter(Mandatory = $true)][string]$Text,
    [Parameter(Mandatory = $true)][string]$MarketplaceName
  )

  $PluginKey = "$PluginName@$MarketplaceName"
  $HeaderCodes = Get-CodexPluginHeaderCodes -MarketplaceName $MarketplaceName
  $InTargetSection = $false
  $HeaderCount = 0
  $EnabledCount = 0
  foreach ($Line in [regex]::Split($Text, "\r?\n")) {
    $Code = Get-TomlCode -Line $Line
    if ($HeaderCodes -ccontains $Code) {
      $HeaderCount += 1
      $InTargetSection = $true
      continue
    }
    if ($Code.StartsWith("[", [System.StringComparison]::Ordinal) -and
        $Code.EndsWith("]", [System.StringComparison]::Ordinal)) {
      if ($Code.Contains($PluginKey)) {
        return $false
      }
      $InTargetSection = $false
    }
    if ($InTargetSection -and $Code -match '^(?:enabled|"enabled"|''enabled'')\s*=') {
      if ($Code -notmatch '^(?:enabled|"enabled"|''enabled'')\s*=\s*true\s*$') {
        return $false
      }
      $EnabledCount += 1
    }
  }
  return $HeaderCount -eq 1 -and $EnabledCount -eq 1
}

function Get-UpdatedCodexConfigText {
  param([Parameter(Mandatory = $true)][string]$MarketplaceName)

  $PluginKey = "$PluginName@$MarketplaceName"
  $Header = "[plugins.`"$PluginKey`"]"
  $HeaderCodes = Get-CodexPluginHeaderCodes -MarketplaceName $MarketplaceName
  $Result = New-Object System.Collections.Generic.List[string]
  $InTargetSection = $false
  $TargetHeaderCount = 0
  $EnabledCount = 0
  $TargetHeaderIndex = -1
  if (Test-Path -LiteralPath $CodexConfigFile) {
    $RawConfig = [System.IO.File]::ReadAllText($CodexConfigFile)
    if ($RawConfig.Length -gt 0 -and $RawConfig[0] -ceq [char]0xfeff) {
      $RawConfig = $RawConfig.Substring(1)
    }
    if ($RawConfig.Contains([char]0) -or $RawConfig.Contains('"""') -or $RawConfig.Contains("'''")) {
      throw "Existing Codex config uses unsupported complex TOML; refusing to modify it."
    }
    $Lines = @([regex]::Split($RawConfig, "\r?\n"))
    if ($Lines.Count -gt 0 -and $Lines[$Lines.Count - 1] -ceq "") {
      $Lines = if ($Lines.Count -eq 1) { @() } else { @($Lines[0..($Lines.Count - 2)]) }
    }
    foreach ($Line in $Lines) {
      $Code = Get-TomlCode -Line $Line
      if ($HeaderCodes -ccontains $Code) {
        $TargetHeaderCount += 1
        if ($TargetHeaderCount -gt 1) {
          throw "Codex config contains duplicate LuchiKey Image plugin tables."
        }
        $InTargetSection = $true
        $TargetHeaderIndex = $Result.Count
        $Result.Add($Line)
        continue
      }
      if ($Code.StartsWith("[", [System.StringComparison]::Ordinal) -and
          $Code.EndsWith("]", [System.StringComparison]::Ordinal)) {
        if ($Code.Contains($PluginKey)) {
          throw "Codex config contains an ambiguous LuchiKey Image plugin table."
        }
        $InTargetSection = $false
      }
      if ($InTargetSection -and $Code -match '^(?:enabled|"enabled"|''enabled'')\s*=') {
        $EnabledCount += 1
        if ($EnabledCount -gt 1) {
          throw "Codex config declares the LuchiKey Image enabled setting more than once."
        }
        $Result.Add("enabled = true")
        continue
      }
      $Result.Add($Line)
    }
  }
  if ($TargetHeaderCount -eq 0) {
    while ($Result.Count -gt 0 -and !$Result[$Result.Count - 1].Trim()) {
      $Result.RemoveAt($Result.Count - 1)
    }
    if ($Result.Count -gt 0) {
      $Result.Add("")
    }
    $Result.Add($Header)
    $Result.Add("enabled = true")
  } elseif ($EnabledCount -eq 0) {
    $Result.Insert($TargetHeaderIndex + 1, "enabled = true")
  }
  while ($Result.Count -gt 0 -and !$Result[$Result.Count - 1].Trim()) {
    $Result.RemoveAt($Result.Count - 1)
  }
  $Updated = ($Result -join [Environment]::NewLine) + [Environment]::NewLine
  if (!(Test-CodexPluginConfigText -Text $Updated -MarketplaceName $MarketplaceName)) {
    throw "Generated Codex plugin configuration failed semantic validation."
  }
  return $Updated
}

function Test-MarketplaceRegistration {
  param([Parameter(Mandatory = $true)][string]$MarketplaceName)

  try {
    $Marketplace = Get-Content -LiteralPath $MarketplaceFile -Raw | ConvertFrom-Json
    if ([string]$Marketplace.name -cne $MarketplaceName) {
      return $false
    }
    $Matches = @($Marketplace.plugins | Where-Object { [string]$_.name -ceq $PluginName })
    if ($Matches.Count -ne 1) {
      return $false
    }
    $Entry = $Matches[0]
    return [string]$Entry.source.source -ceq "local" -and
      [string]$Entry.source.path -ceq "./plugins/$PluginName" -and
      [string]$Entry.policy.installation -ceq "AVAILABLE" -and
      [string]$Entry.policy.authentication -ceq "ON_USE"
  } catch {
    return $false
  }
}

function Test-CodexPluginEnabledConfig {
  param([Parameter(Mandatory = $true)][string]$MarketplaceName)

  if (!(Test-Path -LiteralPath $CodexConfigFile -PathType Leaf)) {
    return $false
  }
  try {
    return Test-CodexPluginConfigText -Text (Get-Content -LiteralPath $CodexConfigFile -Raw) -MarketplaceName $MarketplaceName
  } catch {
    return $false
  }
}

function New-TextStage {
  param(
    [Parameter(Mandatory = $true)][string]$TargetPath,
    [Parameter(Mandatory = $true)][string]$Text
  )

  $Stage = Get-UniqueSiblingPath -TargetPath $TargetPath -Kind "stage"
  [System.IO.File]::WriteAllText($Stage, $Text, $Utf8NoBom)
  return $Stage
}

function Install-VerifiedLocalRelease {
  param(
    [Parameter(Mandatory = $true)][string]$ValidatedRoot,
    [Parameter(Mandatory = $true)][string]$MarketplaceName,
    [string]$MarketplaceJson = ""
  )

  Assert-InstallPathBoundaries
  $CodexCacheParent = Join-Path $CodexRoot "plugins\cache\$MarketplaceName\$PluginName"
  $CodexCacheRoot = Join-Path $CodexCacheParent $Version
  [System.IO.Directory]::CreateDirectory($CodexRoot) | Out-Null
  Assert-InstallPathBoundaries
  Assert-SafeDirectoryChain -TrustRoot $CodexRoot -TargetDirectory $CodexCacheParent
  [System.IO.Directory]::CreateDirectory($PluginParent) | Out-Null
  [System.IO.Directory]::CreateDirectory($MarketplaceRoot) | Out-Null
  [System.IO.Directory]::CreateDirectory($CodexCacheParent) | Out-Null
  Assert-SafeDirectoryChain -TrustRoot $CodexRoot -TargetDirectory $CodexCacheParent

  $PluginStage = Get-UniqueSiblingPath -TargetPath $PluginRoot -Kind "stage"
  $CacheStage = Get-UniqueSiblingPath -TargetPath $CodexCacheRoot -Kind "stage"
  $MarketplaceStage = $null
  $CodexConfigStage = $null
  try {
    Copy-ValidatedPluginTree -SourceRoot $ValidatedRoot -DestinationRoot $PluginStage
    Copy-ValidatedPluginTree -SourceRoot $ValidatedRoot -DestinationRoot $CacheStage
    $MarketplacePlan = if ($MarketplaceJson) {
      [pscustomobject]@{ Name = $MarketplaceName; Json = $MarketplaceJson }
    } else {
      Get-MarketplacePlan -RequiredMarketplaceName $MarketplaceName
    }
    $MarketplaceStage = New-TextStage -TargetPath $MarketplaceFile -Text $MarketplacePlan.Json
    $CodexConfigStage = New-TextStage -TargetPath $CodexConfigFile -Text (Get-UpdatedCodexConfigText -MarketplaceName $MarketplaceName)

    $Changes = @(
      [pscustomobject]@{ Target = $PluginRoot; Stage = $PluginStage },
      [pscustomobject]@{ Target = $CodexCacheRoot; Stage = $CacheStage },
      [pscustomobject]@{ Target = $MarketplaceFile; Stage = $MarketplaceStage },
      [pscustomobject]@{ Target = $CodexConfigFile; Stage = $CodexConfigStage }
    )
    Invoke-AtomicPathTransaction -Changes $Changes -PostCommitValidation {
      if (!(Test-InstalledReleaseBytes -InstalledRoot $PluginRoot -ValidatedRoot $ValidatedRoot)) {
        throw "Installed local plugin bytes differ from the validated release."
      }
      if (!(Test-InstalledReleaseBytes -InstalledRoot $CodexCacheRoot -ValidatedRoot $ValidatedRoot)) {
        throw "Installed Codex cache bytes differ from the validated release."
      }
      if (!(Test-MarketplaceRegistration -MarketplaceName $MarketplaceName)) {
        throw "Installed marketplace entry does not match the local plugin release."
      }
      if ([System.IO.File]::ReadAllText($MarketplaceFile) -cne $MarketplacePlan.Json) {
        throw "Installed marketplace bytes differ from the frozen local registration plan."
      }
      if (!(Test-CodexPluginEnabledConfig -MarketplaceName $MarketplaceName)) {
        throw "Installed Codex plugin configuration is not predictably enabled."
      }
    }
  } finally {
    foreach ($Temporary in @($PluginStage, $CacheStage, $MarketplaceStage, $CodexConfigStage)) {
      if ($Temporary -and (Test-PathExists -Path $Temporary)) {
        Remove-InstallerTemporaryPath -Path $Temporary
      }
    }
  }

  return [pscustomobject]@{
    CacheRoot = $CodexCacheRoot
    MarketplaceName = $MarketplaceName
  }
}

function ConvertFrom-SecureStringToPlainText {
  param([Parameter(Mandatory = $true)][System.Security.SecureString]$SecureString)

  $Bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureString)
  try {
    return [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($Bstr)
  } finally {
    if ($Bstr -ne [IntPtr]::Zero) {
      [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($Bstr)
    }
  }
}

function Get-ConfiguredLuchiKeyApiKey {
  if ($env:LUCHIKEY_API_KEY -and $env:LUCHIKEY_API_KEY.Trim()) {
    return $env:LUCHIKEY_API_KEY.Trim()
  }
  if (!(Test-Path -LiteralPath $ConfigFile -PathType Leaf)) {
    return ""
  }
  try {
    $Existing = Get-Content -LiteralPath $ConfigFile -Raw | ConvertFrom-Json
    $Key = if ($Existing.api_key) { $Existing.api_key } else { $Existing.luchikey_api_key }
    if ($Key -and $Key.Trim()) {
      return $Key.Trim()
    }
  } catch {}
  return ""
}

function Write-LuchiKeyImageConfig {
  param([Parameter(Mandatory = $true)][string]$ApiKey)

  $Config = [ordered]@{
    api_key = $ApiKey.Trim()
    base_url = "https://sub2api.luchikey.com"
    image_endpoint = "/v1/images/generations"
    image_edit_endpoint = "/v1/images/edits"
    image_model = "gpt-image-2"
    plugin_version = $Version
    configured_at = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
  }
  $Json = ($Config | ConvertTo-Json -Depth 5) + [Environment]::NewLine
  Set-PrivateCredentialFile -Path $ConfigFile -Json $Json
}

function Test-LuchiKeyImageApiKey {
  param([Parameter(Mandatory = $true)][string]$ApiKey)

  if (!$ApiKey -or !$ApiKey.Trim()) {
    return [pscustomobject]@{ State = "Invalid"; Status = 0; Message = "API key is empty." }
  }

  $Request = [System.Net.HttpWebRequest]::Create("https://sub2api.luchikey.com/v1/models")
  $Request.Method = "GET"
  $Request.AllowAutoRedirect = $false
  $Request.Timeout = 20000
  $Request.ReadWriteTimeout = 20000
  $Request.Accept = "application/json"
  $Request.UserAgent = "luchikey-image-installer/$Version"
  $Request.Headers[[System.Net.HttpRequestHeader]::Authorization] = "Bearer $($ApiKey.Trim())"
  $Response = $null
  try {
    $Response = $Request.GetResponse()
    $Status = [int]$Response.StatusCode
    if ($Status -ge 200 -and $Status -lt 300) {
      return [pscustomobject]@{ State = "Verified"; Status = $Status; Message = "API key verified." }
    }
    if ($Status -eq 401 -or $Status -eq 403) {
      return [pscustomobject]@{ State = "Invalid"; Status = $Status; Message = "LuchiKey rejected the API key." }
    }
    return [pscustomobject]@{ State = "Unavailable"; Status = $Status; Message = "API key verification is unavailable (HTTP $Status)." }
  } catch [System.Net.WebException] {
    $Status = 0
    if ($_.Exception.Response) {
      $Status = [int]$_.Exception.Response.StatusCode
    }
    if ($Status -eq 401 -or $Status -eq 403) {
      return [pscustomobject]@{ State = "Invalid"; Status = $Status; Message = "LuchiKey rejected the API key." }
    }
    $Detail = if ($Status) { "HTTP $Status" } else { "network error" }
    return [pscustomobject]@{ State = "Unavailable"; Status = $Status; Message = "API key verification is unavailable ($Detail)." }
  } catch {
    return [pscustomobject]@{ State = "Unavailable"; Status = 0; Message = "API key verification is unavailable (network error)." }
  } finally {
    if ($Response) { $Response.Close() }
  }
}

function Read-LuchiKeyImageApiKey {
  Write-Host ""
  Write-Host "Paste your LuchiKey API key to finish setup."
  Write-Host "The key is saved locally at: $ConfigFile"
  $SecureKey = Read-Host -AsSecureString "LUCHIKEY_API_KEY"
  return ConvertFrom-SecureStringToPlainText -SecureString $SecureKey
}

function Save-ConfiguredApiKey {
  param(
    [Parameter(Mandatory = $true)][string]$ApiKey,
    [Parameter(Mandatory = $true)]$Validation
  )

  Write-LuchiKeyImageConfig -ApiKey $ApiKey
  if ($Validation.State -ceq "Verified") {
    Write-Host "LuchiKey API key was saved locally and verified."
    return [pscustomobject]@{ Configured = $true; Verified = $true; State = "Verified" }
  }
  Write-Warning "$($Validation.Message) The key was saved locally but was not verified."
  return [pscustomobject]@{ Configured = $true; Verified = $false; State = "Unavailable" }
}

function Ensure-LuchiKeyImageConfig {
  $ExistingKey = Get-ConfiguredLuchiKeyApiKey
  if ($ExistingKey) {
    $Validation = Test-LuchiKeyImageApiKey -ApiKey $ExistingKey
    if ($Validation.State -ceq "Verified" -or $Validation.State -ceq "Unavailable") {
      return Save-ConfiguredApiKey -ApiKey $ExistingKey -Validation $Validation
    }
    Write-Warning "The existing LuchiKey API key is invalid or disabled. Please paste an active key."
  }

  for ($Attempt = 1; $Attempt -le 3; $Attempt += 1) {
    $PlainKey = Read-LuchiKeyImageApiKey
    if (!$PlainKey -or !$PlainKey.Trim()) {
      Write-Warning "No API key was entered. The plugin is installed, but image generation will ask for LUCHIKEY_API_KEY later."
      return [pscustomobject]@{ Configured = $false; Verified = $false; State = "Missing" }
    }
    $Validation = Test-LuchiKeyImageApiKey -ApiKey $PlainKey
    if ($Validation.State -ceq "Verified" -or $Validation.State -ceq "Unavailable") {
      return Save-ConfiguredApiKey -ApiKey $PlainKey -Validation $Validation
    }
    Write-Warning "That LuchiKey API key was rejected. Please check that it is active and has access to image models."
  }

  Write-Warning "API key verification failed too many times. The plugin is installed, but image generation will ask for a valid LUCHIKEY_API_KEY later."
  return [pscustomobject]@{ Configured = $false; Verified = $false; State = "Invalid" }
}

function Invoke-LuchiKeyImageInstaller {
  Assert-InstallPathBoundaries
  $InstallLock = Enter-LuchiKeyImageInstallLock
  $TempRoot = $null
  try {
    $TempRoot = New-PrivateTempDirectory
    $RunId = [Guid]::NewGuid().ToString("N")
    $ZipPath = Join-Path $TempRoot "luchikey-image-codex-plugin-$Version-$RunId.zip"
    $ExtractedRoot = Join-Path $TempRoot "validated-plugin-$([Guid]::NewGuid().ToString('N'))"

    Write-Host "Downloading fixed LuchiKey Image Codex plugin $Version..."
    Receive-BoundedHttpsFile -Uri $ZipUrl -Destination $ZipPath -MaximumBytes $MaxZipBytes
    Assert-PinnedArchiveHash -ZipPath $ZipPath
    Expand-ValidatedPluginArchive -ZipPath $ZipPath -DestinationRoot $ExtractedRoot | Out-Null

    $InitialPlan = Get-MarketplacePlan
    $MarketplaceName = $InitialPlan.Name
    $InstallResult = Install-VerifiedLocalRelease -ValidatedRoot $ExtractedRoot -MarketplaceName $MarketplaceName -MarketplaceJson $InitialPlan.Json
    if (!(Test-InstalledReleaseBytes -InstalledRoot $PluginRoot -ValidatedRoot $ExtractedRoot) -or
        !(Test-InstalledReleaseBytes -InstalledRoot $InstallResult.CacheRoot -ValidatedRoot $ExtractedRoot)) {
      throw "Final installed plugin bytes do not match the checksum-validated package."
    }
    if (!(Test-MarketplaceRegistration -MarketplaceName $MarketplaceName) -or
        !(Test-CodexPluginEnabledConfig -MarketplaceName $MarketplaceName)) {
      throw "Final local plugin registration does not match the verified release."
    }

    $KeyResult = Ensure-LuchiKeyImageConfig

    Write-Host ""
    Write-Host "LuchiKey Image is installed with the verified local Codex fallback."
    if ($KeyResult.Verified) {
      Write-Host "LuchiKey API key is saved locally and verified for the plugin."
    } elseif ($KeyResult.Configured) {
      Write-Host "LuchiKey API key is saved locally, but online verification was unavailable."
    } else {
      Write-Host "API key is not configured yet. Run this installer again and paste your LuchiKey API key."
    }
    Write-Host "Setup is complete in this terminal. No Codex plugin page jump is required."
    Write-Host "Restart Codex, then ask: Generate a small yellow duck image in this conversation."
    Write-Host "Plugin: $PluginRoot"
    Write-Host "Plugin cache: $($InstallResult.CacheRoot)"
    Write-Host "Config: $ConfigFile"
    Write-Host "Marketplace: $MarketplaceFile"
  } finally {
    if ($TempRoot) {
      try { Remove-PrivateTempDirectory -Path $TempRoot } catch { Write-Warning $_.Exception.Message }
    }
    Exit-LuchiKeyImageInstallLock -Lock $InstallLock
  }
}

if ($MyInvocation.InvocationName -ne ".") {
  Invoke-LuchiKeyImageInstaller
}
