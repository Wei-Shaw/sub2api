(() => {
  const LOCALE_KEY = 'sub2api_locale'
  const locales = ['zh', 'en']
  const homePath = '/home'
  const authPaths = ['/login', '/register']

  const homeCopy = {
    zh: {
      title: 'API Token 中转站',
      pageNavLabel: '主导航',
      brandLabel: 'API Token 中转站首页',
      brandImageAlt: 'API Token 中转站',
      accountLabel: '账户入口',
      serviceTagsLabel: '服务标签',
      coreCapabilitiesLabel: '核心能力',
      visualLabel: 'API 中转能力概览',
      copyBaseAria: '复制 Base URL',
      nav: ['首页', '教程', '控制台'],
      register: '注册',
      login: '登录',
      pillPrimary: '多模型接入 · 标准 API · 快速上线',
      pillSoft: 'OpenAI · Claude · Gemini · Codex',
      h1: 'API Token 中转站',
      subtitle:
        '<strong>安全 · 稳定 · 高效的 API 中转服务。</strong> 统一管理密钥、额度、分组和请求链路，让模型调用更稳定，业务集成更轻。',
      baseIntro: '只需替换一行',
      copyHint: '点击复制',
      copiedHint: '已复制',
      start: '立即开始',
      video: '视频配置教程',
      badges: ['Claude / GPT 接入', 'OpenAI 兼容接口', '用量与费用统计'],
      capLabel: '能力概览',
      capTitle: '多平台模型接入 · 统一 API · 快速上线',
      accessEyebrow: 'ACCESS',
      accessTitle: '多模型接入',
      accessText: '当前支持 OpenAI、Claude、Gemini 等模型入口，适合 GPT、Codex 与聚合调用场景。',
      apiEyebrow: 'API',
      apiTitle: '标准化接口',
      apiText: '兼容 OpenAI 风格 API，方便接入现有项目、脚本、客户端和自动化流程。',
      ecosystemTitle: 'SUPPORTED ECOSYSTEM',
      ready: 'READY',
      routeTitle: '统一 Base URL',
      featuresTitle: '一个入口，管理多平台模型调用',
      featuresText:
        '从密钥、分组、额度、渠道到用量统计，常见运营能力集中在控制台完成，减少重复配置和排障成本。',
      featureCards: [
        ['API', '统一中转', '兼容多平台请求入口，业务侧只需维护统一的调用地址和 Token。'],
        ['KEY', '密钥保护', '集中管理 API Token、用户权限和分组策略，降低密钥泄露和误用风险。'],
        ['OPS', '状态可见', '渠道状态、使用量、费用和请求记录统一展示，方便日常维护。'],
        ['SAFE', '策略调度', '支持账号能力、额度阈值和风控状态配合调度，减少异常请求影响。']
      ],
      workflowTitle: '四步完成接入',
      workflowText:
        '保留常见 OpenAI 兼容调用习惯，同时提供控制台配置和视频教程，新用户也能按步骤完成接入。',
      workflowCards: [
        ['01', '登录控制台', '进入控制台后创建或查看自己的 API Token，确认账号分组和可用额度。'],
        ['02', '复制接入地址', '在配置教程中选择 OpenAI、Claude、Gemini 或客户端插件对应的配置方式。'],
        ['03', '替换模型调用', '把业务里的 Base URL 和 Token 换成中转站提供的配置，保持原有代码结构。'],
        ['04', '查看用量状态', '通过仪表盘、渠道状态和用量明细持续检查调用质量，发现问题及时调整。']
      ],
      tutorialTitle: '需要详细配置说明？',
      tutorialText:
        '视频教程和控制台内的配置教程会覆盖客户端、Base URL、Token、模型名称和常见排错步骤。第一次接入建议先看教程，再进入控制台配置。',
      tutorialButtons: ['进入控制台', '观看视频教程'],
      toast: '已复制 https://sub2api.luchikey.com'
    },
    en: {
      title: 'API Token Relay',
      pageNavLabel: 'Primary navigation',
      brandLabel: 'API Token Relay home',
      brandImageAlt: 'API Token Relay',
      accountLabel: 'Account entry',
      serviceTagsLabel: 'Service tags',
      coreCapabilitiesLabel: 'Core capabilities',
      visualLabel: 'API relay capability overview',
      copyBaseAria: 'Copy Base URL',
      nav: ['Home', 'Tutorials', 'Console'],
      register: 'Register',
      login: 'Login',
      pillPrimary: 'Multi-model access · Standard API · Quick launch',
      pillSoft: 'OpenAI · Claude · Gemini · Codex',
      h1: 'API Token Relay',
      subtitle:
        '<strong>Secure, stable, efficient API relay service.</strong> Manage keys, quotas, groups, and request routing in one place so model calls stay reliable and integrations stay simple.',
      baseIntro: 'Change one line only',
      copyHint: 'Copy',
      copiedHint: 'Copied',
      start: 'Get started',
      video: 'Video setup guide',
      badges: ['Claude / GPT access', 'OpenAI-compatible API', 'Usage and cost analytics'],
      capLabel: 'Capability Overview',
      capTitle: 'Multi-platform model access · Unified API · Fast launch',
      accessEyebrow: 'ACCESS',
      accessTitle: 'Multi-model access',
      accessText:
        'Supports OpenAI, Claude, Gemini, and more model entrances for GPT, Codex, and aggregated workflows.',
      apiEyebrow: 'API',
      apiTitle: 'Standardized API',
      apiText:
        'Compatible with OpenAI-style APIs, so existing projects, scripts, clients, and automation can connect quickly.',
      ecosystemTitle: 'SUPPORTED ECOSYSTEM',
      ready: 'READY',
      routeTitle: 'Unified Base URL',
      featuresTitle: 'One entry point for multi-platform model calls',
      featuresText:
        'Manage keys, groups, quotas, channels, and usage analytics from one console, reducing repeated setup and troubleshooting overhead.',
      featureCards: [
        ['API', 'Unified relay', 'Use one compatible endpoint for multiple platforms while keeping one Base URL and Token.'],
        ['KEY', 'Token protection', 'Centralize API tokens, user permissions, and group policies to reduce leakage and misuse risk.'],
        ['OPS', 'Operational visibility', 'View channel status, usage, cost, and request records together for daily maintenance.'],
        ['SAFE', 'Policy scheduling', 'Combine account capability, quota thresholds, and risk states to reduce abnormal request impact.']
      ],
      workflowTitle: 'Connect in four steps',
      workflowText:
        'Keep familiar OpenAI-compatible calling habits while using console configuration and video guidance for a smoother first setup.',
      workflowCards: [
        ['01', 'Log in to console', 'Create or view your API Token, then confirm the account group and available quota.'],
        ['02', 'Copy connection details', 'Choose the setup style for OpenAI, Claude, Gemini, or client plugins in the tutorial.'],
        ['03', 'Replace model calls', 'Switch your Base URL and Token to the relay configuration while keeping your code structure.'],
        ['04', 'Review usage status', 'Use the dashboard, channel status, and usage details to monitor quality and adjust quickly.']
      ],
      tutorialTitle: 'Need detailed setup guidance?',
      tutorialText:
        'The video guide and console tutorials cover clients, Base URL, Token, model names, and common troubleshooting steps. For a first integration, review the guide before configuring the console.',
      tutorialButtons: ['Open console', 'Watch video tutorial'],
      toast: 'Copied https://sub2api.luchikey.com'
    }
  }

  function normalizeLocale(value) {
    return locales.includes(value) ? value : null
  }

  function getPreferredLocale() {
    try {
      const saved = normalizeLocale(localStorage.getItem(LOCALE_KEY))
      if (saved) return saved
    } catch {}
    return navigator.language && navigator.language.toLowerCase().startsWith('zh') ? 'zh' : 'en'
  }

  function persistLocale(locale) {
    try {
      localStorage.setItem(LOCALE_KEY, locale)
    } catch {}
    document.documentElement.setAttribute('lang', locale === 'zh' ? 'zh-CN' : 'en')
  }

  function injectSharedStyles() {
    if (document.querySelector('style[data-luchikey-i18n-switch]')) return
    const style = document.createElement('style')
    style.setAttribute('data-luchikey-i18n-switch', '1')
    style.textContent = `
      .language-switch {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 2px;
        min-height: 42px;
        padding: 3px;
        border: 1px solid rgba(69, 132, 238, 0.24);
        border-radius: 999px;
        background: rgba(255, 255, 255, 0.68);
        box-shadow: inset 0 1px rgba(255, 255, 255, 0.9), 0 12px 28px rgba(50, 111, 255, 0.1);
        backdrop-filter: blur(18px);
      }

      .language-switch .locale-option {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 38px;
        height: 34px;
        padding: 0 10px;
        border: 0;
        border-radius: 999px;
        color: #4d5e77;
        background: transparent;
        font: inherit;
        font-size: 13px;
        font-weight: 950;
        letter-spacing: 0;
        line-height: 1;
        cursor: pointer;
        transition: color 0.18s ease, background 0.18s ease, box-shadow 0.18s ease, transform 0.18s ease;
      }

      .language-switch .locale-option:hover {
        color: #286dff;
        transform: translateY(-1px);
      }

      .language-switch .locale-option.active,
      .language-switch .locale-option[aria-pressed="true"] {
        color: #fff;
        background: linear-gradient(135deg, #4aa2ff, #326fff);
        box-shadow: 0 10px 20px rgba(50, 111, 255, 0.22);
      }

      .luchikey-spa-locale-switch {
        position: fixed;
        top: 18px;
        right: 18px;
        z-index: 80;
        min-height: 38px;
      }

      .luchikey-spa-locale-switch .locale-option {
        min-width: 36px;
        height: 32px;
      }

      @media (max-width: 780px) {
        .language-switch {
          min-height: 40px;
          padding: 2px;
        }

        .language-switch .locale-option {
          min-width: 32px;
          height: 32px;
          padding: 0 8px;
          font-size: 12px;
        }

        .luchikey-spa-locale-switch {
          top: 14px;
          right: 14px;
        }
      }
    `
    document.head.appendChild(style)
  }

  function isHomePage() {
    const path = window.location.pathname
    return path === '/' || path === '/index.html' || path === homePath || path === `${homePath}/`
  }

  function isAuthPage() {
    return authPaths.some((path) => window.location.pathname === path)
  }

  function setText(selector, value) {
    const node = document.querySelector(selector)
    if (node) node.textContent = value
  }

  function setHtml(selector, value) {
    const node = document.querySelector(selector)
    if (node) node.innerHTML = value
  }

  function setAttr(selector, attr, value) {
    const node = document.querySelector(selector)
    if (node) node.setAttribute(attr, value)
  }

  function setList(selector, values, setter = (node, value) => {
    node.textContent = value
  }) {
    document.querySelectorAll(selector).forEach((node, index) => {
      if (values[index] !== undefined) setter(node, values[index], index)
    })
  }

  function applyHomeLocale(locale) {
    if (!isHomePage()) return
    const copy = homeCopy[locale]
    document.title = copy.title

    setAttr('.nav', 'aria-label', copy.pageNavLabel)
    setAttr('.brand', 'aria-label', copy.brandLabel)
    setAttr('.brand-logo img', 'alt', copy.brandImageAlt)
    setAttr('.nav-actions', 'aria-label', copy.accountLabel)
    setAttr('.hero-pills', 'aria-label', copy.serviceTagsLabel)
    setAttr('.badges', 'aria-label', copy.coreCapabilitiesLabel)
    setAttr('.visual', 'aria-label', copy.visualLabel)
    setAttr('[data-copy-url]', 'aria-label', copy.copyBaseAria)

    setList('.nav-links .nav-link', copy.nav)
    setText('.nav-button.register', copy.register)
    setText('.nav-button:not(.register)', copy.login)
    setText('.hero-pills .pill:not(.soft)', copy.pillPrimary)
    setText('.hero-pills .pill.soft', copy.pillSoft)
    setText('h1', copy.h1)
    setHtml('.subtitle', copy.subtitle)
    setText('.base-pill > span:first-child', copy.baseIntro)
    setText('.copy-hint', copy.copyHint)
    const copyButton = document.querySelector('[data-copy-url]')
    if (copyButton) {
      copyButton.dataset.copyHint = copy.copyHint
      copyButton.dataset.copiedHint = copy.copiedHint
    }
    setList('.hero-row .hero-button', [copy.start, copy.video])
    setList('.badges span', copy.badges)
    setText('.cap-label span', copy.capLabel)
    setText('.cap-label h2', copy.capTitle)
    setList('.overview-card', [
      [copy.accessEyebrow, copy.accessTitle, copy.accessText],
      [copy.apiEyebrow, copy.apiTitle, copy.apiText]
    ], (node, values) => {
      const [eyebrow, title, text] = values
      const span = node.querySelector('span')
      const heading = node.querySelector('h3')
      const paragraph = node.querySelector('p')
      if (span) span.textContent = eyebrow
      if (heading) heading.textContent = title
      if (paragraph) paragraph.textContent = text
    })
    setText('.ecosystem-title span', copy.ecosystemTitle)
    setText('.ecosystem-title b', copy.ready)
    setText('.route-card > span', copy.routeTitle)

    setList('.section-heading', [
      [copy.featuresTitle, copy.featuresText],
      [copy.workflowTitle, copy.workflowText]
    ], (node, values) => {
      const [title, text] = values
      const heading = node.querySelector('h2')
      const paragraph = node.querySelector('p')
      if (heading) heading.textContent = title
      if (paragraph) paragraph.textContent = text
    })
    setList('.feature-card', copy.featureCards, (node, values) => {
      const [code, title, text] = values
      const codeNode = node.querySelector('.feature-code')
      const heading = node.querySelector('h3')
      const paragraph = node.querySelector('p')
      if (codeNode) codeNode.textContent = code
      if (heading) heading.textContent = title
      if (paragraph) paragraph.textContent = text
    })
    setList('.step', copy.workflowCards, (node, values) => {
      const [number, title, text] = values
      const numberNode = node.querySelector('.step-number')
      const heading = node.querySelector('h3')
      const paragraph = node.querySelector('p')
      if (numberNode) numberNode.textContent = number
      if (heading) heading.textContent = title
      if (paragraph) paragraph.textContent = text
    })
    setText('.tutorial-panel h2', copy.tutorialTitle)
    setText('.tutorial-panel p', copy.tutorialText)
    setList('.tutorial-actions .tutorial-button', copy.tutorialButtons)
    setText('#copyToast', copy.toast)
  }

  function updateSwitchState(locale = getPreferredLocale()) {
    document.querySelectorAll('[data-luchikey-locale-option]').forEach((button) => {
      const active = button.getAttribute('data-luchikey-locale-option') === locale
      button.setAttribute('aria-pressed', active ? 'true' : 'false')
      button.classList.toggle('active', active)
    })
  }

  function setLocale(locale, options = {}) {
    if (!normalizeLocale(locale)) return
    const previous = getPreferredLocale()
    persistLocale(locale)
    applyHomeLocale(locale)
    updateSwitchState(locale)
    if (options.reload && previous !== locale) {
      window.location.reload()
    }
  }

  function bindLocaleSwitches() {
    document.querySelectorAll('[data-luchikey-locale-option]').forEach((button) => {
      if (button.dataset.luchikeyLocaleBound === '1') return
      button.dataset.luchikeyLocaleBound = '1'
      button.addEventListener('click', () => {
        const locale = button.getAttribute('data-luchikey-locale-option')
        setLocale(locale, { reload: !isHomePage() })
      })
    })
    updateSwitchState()
  }

  function injectSpaSwitch() {
    const existing = document.querySelector('[data-luchikey-spa-locale-switch]')
    if (!isAuthPage()) {
      if (existing) existing.remove()
      return
    }
    if (existing) {
      bindLocaleSwitches()
      return
    }

    const switcher = document.createElement('div')
    switcher.className = 'luchikey-spa-locale-switch language-switch'
    switcher.setAttribute('data-luchikey-spa-locale-switch', '1')
    switcher.setAttribute('role', 'group')
    switcher.setAttribute('aria-label', 'Language')
    switcher.innerHTML = [
      '<button type="button" class="locale-option" data-luchikey-locale-option="zh" aria-pressed="false">中</button>',
      '<button type="button" class="locale-option" data-luchikey-locale-option="en" aria-pressed="false">EN</button>'
    ].join('')
    document.body.appendChild(switcher)
    bindLocaleSwitches()
  }

  function installSpaSwitchObserver() {
    let lastPath = window.location.pathname
    const update = () => {
      if (lastPath !== window.location.pathname) {
        lastPath = window.location.pathname
      }
      injectSpaSwitch()
    }

    ;['pushState', 'replaceState'].forEach((method) => {
      const original = history[method]
      history[method] = function patchedHistoryState(...args) {
        const result = original.apply(this, args)
        window.setTimeout(update, 0)
        return result
      }
    })
    window.addEventListener('popstate', update)

    const observer = new MutationObserver(() => injectSpaSwitch())
    if (document.body) {
      observer.observe(document.body, { childList: true, subtree: true })
    }
    injectSpaSwitch()
  }

  function init() {
    const locale = getPreferredLocale()
    injectSharedStyles()
    persistLocale(locale)
    applyHomeLocale(locale)
    bindLocaleSwitches()
    installSpaSwitchObserver()

    window.addEventListener('storage', (event) => {
      if (event.key !== LOCALE_KEY) return
      const next = normalizeLocale(event.newValue) || getPreferredLocale()
      applyHomeLocale(next)
      updateSwitchState(next)
      if (isAuthPage()) window.location.reload()
    })

    window.LuchikeyI18nSwitch = {
      getLocale: getPreferredLocale,
      setLocale
    }
  }

  const initialLocale = getPreferredLocale()
  persistLocale(initialLocale)
  injectSharedStyles()

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true })
  } else {
    init()
  }
})()
