(() => {
  if (window.__LK_PERF_PREFETCH_INSTALLED) return;
  window.__LK_PERF_PREFETCH_INSTALLED = true;

  const routeAssets = {
    core: [
      "/assets/index-CTrPLqGV.js",
      "/assets/vendor-vue-BRjbeJGJ.js",
      "/assets/vendor-i18n-BZoxDmZq.js",
      "/assets/vendor-misc-T69nC9V6.js",
      "/assets/vendor-misc-DB0Q8XAf.css",
      "/assets/index-BFZ7Di1p.css",
    ],
    appCommon: [
      "/assets/AppLayout.vue_vue_type_script_setup_true_lang-BS3tJObN.js",
      "/assets/LocaleSwitcher-BjjFnK8N.js",
      "/assets/LocaleSwitcher-CjvPxOhx.css",
      "/assets/AppHeader-DanOdqxi.css",
      "/assets/LoadingSpinner-koHNBVUl.js",
      "/assets/LoadingSpinner-DT-rtrW_.css",
    ],
    dashboard: [
      "/assets/DashboardView-3hZLzVl7.js",
      "/assets/usage-DJ9pEjd1.js",
      "/assets/DateRangePicker-CQz90_hP.js",
      "/assets/DateRangePicker-DnLNOoiJ.css",
      "/assets/vendor-chart-DAx887Kz.js",
      "/assets/TokenUsageTrend.vue_vue_type_script_setup_true_lang-BU7n7FDR.js",
      "/assets/EmptyState.vue_vue_type_script_setup_true_lang-ukuKHneu.js",
      "/assets/user-ehWjh5rk.js",
    ],
    keys: [
      "/assets/KeysView-Byo8RVC6.js",
      "/assets/Pagination-1-WDsA0B.js",
      "/assets/Pagination-DgYObafU.css",
      "/assets/Select-BsgDcZbH.js",
      "/assets/Select-D1KmlnrJ.css",
      "/assets/TablePageLayout-C1xEMJdV.js",
      "/assets/TablePageLayout-DZ8zDPQ6.css",
      "/assets/DataTable-CL4Ww6At.js",
      "/assets/DataTable-BTCQqSWg.css",
      "/assets/vendor-ui-CiLV-J8d.js",
      "/assets/GroupBadge.vue_vue_type_script_setup_true_lang-CtJ37qkd.js",
      "/assets/PlatformIcon.vue_vue_type_script_setup_true_lang-BB_cIYal.js",
    ],
    usage: [
      "/assets/UsageView-FC5LYXFy.js",
      "/assets/DateRangePicker-CQz90_hP.js",
      "/assets/DateRangePicker-DnLNOoiJ.css",
      "/assets/imageUsage-Ddcm5QgD.js",
      "/assets/TablePageLayout-C1xEMJdV.js",
      "/assets/DataTable-CL4Ww6At.js",
      "/assets/Pagination-1-WDsA0B.js",
    ],
    pricing: [
      "/assets/AvailableChannelsView-DmftK__h.js",
      "/assets/AvailableChannelsTable-DqSI0Ms3.js",
      "/assets/ModelIcon-B2pwqx0Y.js",
      "/assets/ModelIcon-BR3Adxor.css",
      "/assets/AvailableChannelsTable-BZQKCgjb.css",
      "/assets/AvailableChannelsView-BxqImjep.css",
      "/assets/platformColors-D43pBspe.js",
      "/assets/apiError-BPX0TiUA.js",
    ],
    tutorial: ["/assets/TutorialView-DqjtCk6n.js", "/assets/TutorialView-BDQGAO7K.css"],
    profile: ["/assets/ProfileView-CDseOMPJ.js", "/assets/user-ehWjh5rk.js", "/assets/apiError-BPX0TiUA.js"],
    subscriptions: ["/assets/SubscriptionsView-ASLI2QcQ.js", "/assets/subscriptionQuota-BxYniwXV.js"],
    purchase: ["/assets/PaymentView-afIIO-WR.js", "/assets/payment-BxxGQ1QX.js", "/assets/payment-Cs34EfZw.js", "/assets/paymentFlow-DOZxmIir.js"],
    orders: ["/assets/UserOrdersView-CD-XuDMr.js", "/assets/OrderTable.vue_vue_type_script_setup_true_lang-qLxtrhvH.js"],
    redeem: ["/assets/RedeemView-BJsV29Do.js", "/assets/RedeemView-ChkGqhY_.css"],
    contact: ["/assets/ContactView-DsZWzou0.js", "/assets/ContactView-DO3m7Jtv.css"],
    adminDashboard: ["/assets/DashboardView-jbu-v6rn.js", "/assets/ModelDistributionChart.vue_vue_type_script_setup_true_lang-DO-njcKs.js"],
    adminAccounts: [
      "/assets/AccountsView-BoxUClmz.js",
      "/assets/AccountsView-C3mLyCVF.css",
      "/assets/vendor-ui-CiLV-J8d.js",
      "/assets/vendor-chart-DAx887Kz.js",
      "/assets/ModelWhitelistSelector.vue_vue_type_script_setup_true_lang-CpP-spoe.js",
      "/assets/ProxySelector-CvBY6C_P.js",
      "/assets/ProxySelector-CL3006OT.css",
    ],
    adminUsers: ["/assets/UsersView-B9-LAQ5e.js", "/assets/UsersView-DK3Tutsw.css", "/assets/vendor-ui-CiLV-J8d.js"],
    adminGroups: ["/assets/GroupsView-Mmvv_Tnb.js", "/assets/GroupsView-CDzTzhWl.css", "/assets/vendor-ui-CiLV-J8d.js"],
    adminChannels: ["/assets/ChannelsView-jzJaWd6Z.js", "/assets/ChannelsView-DZ_KNepz.css", "/assets/ModelTagInput.vue_vue_type_script_setup_true_lang-ClgdqW8C.js"],
    adminMonitor: ["/assets/ChannelMonitorView-DXdsXpV6.js", "/assets/useChannelMonitorFormat-CqzRtqsp.js"],
    adminSettings: ["/assets/SettingsView-CaFBAxs4.js", "/assets/SettingsView-CljlXpQG.css", "/assets/providerConfig-Bj4KpYoZ.js", "/assets/paymentFlow-DOZxmIir.js"],
  };

  const prefetched = new Set();
  const queued = [];
  let flushing = false;

  function importMap() {
    const node = document.querySelector('script[type="importmap"]');
    if (!node) return {};
    try {
      return JSON.parse(node.textContent || "{}").imports || {};
    } catch {
      return {};
    }
  }

  const map = importMap();

  function mapped(url) {
    return map[url] || url;
  }

  function canBulkPrefetch() {
    const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
    if (!connection) return true;
    if (connection.saveData) return false;
    return !/^(slow-)?2g$/i.test(connection.effectiveType || "");
  }

  function linkExists(url, rel) {
    const escaped = url.replace(/"/g, '\\"');
    return Boolean(document.querySelector('link[href="' + escaped + '"]' + (rel ? '[rel="' + rel + '"]' : "")));
  }

  function addLink(url, reason, immediate) {
    const href = mapped(url);
    if (!href || prefetched.has(href)) return;
    prefetched.add(href);
    const isCss = href.endsWith(".css");
    const rel = immediate ? (isCss ? "preload" : "modulepreload") : "prefetch";
    if (linkExists(href) || linkExists(href, "stylesheet")) return;
    const link = document.createElement("link");
    link.rel = rel;
    link.href = href;
    link.setAttribute("data-lk-prefetch", reason || "route");
    link.setAttribute("data-lk-prefetch-mode", immediate ? "immediate" : "idle");
    if (isCss) {
      link.as = "style";
      link.crossOrigin = "";
    } else {
      link.as = "script";
      link.crossOrigin = "";
    }
    document.head.appendChild(link);
  }

  function flush() {
    if (flushing) return;
    flushing = true;
    const step = () => {
      const item = queued.shift();
      if (!item) {
        flushing = false;
        return;
      }
      addLink(item.url, item.reason, item.immediate);
      setTimeout(step, item.immediate ? 0 : 120);
    };
    step();
  }

  function enqueue(urls, reason, immediate) {
    urls.forEach((url) => queued.push({ url, reason, immediate }));
    flush();
  }

  function assetsForPath(pathname) {
    const path = String(pathname || location.pathname || "/").toLowerCase();
    const groups = ["core"];
    if (!/^\/(home|login|register|forgot-password|key-usage|legal|auth)/.test(path)) groups.push("appCommon");
    if (path.startsWith("/dashboard")) groups.push("dashboard");
    else if (path.startsWith("/keys")) groups.push("keys");
    else if (path.startsWith("/usage")) groups.push("usage");
    else if (path.startsWith("/available-channels") || path.startsWith("/price")) groups.push("pricing");
    else if (path.startsWith("/tutorial")) groups.push("tutorial");
    else if (path.startsWith("/profile")) groups.push("profile");
    else if (path.startsWith("/subscriptions")) groups.push("subscriptions");
    else if (path.startsWith("/purchase")) groups.push("purchase");
    else if (path.startsWith("/orders")) groups.push("orders");
    else if (path.startsWith("/redeem")) groups.push("redeem");
    else if (path.startsWith("/contact")) groups.push("contact");
    else if (path.startsWith("/admin/dashboard")) groups.push("appCommon", "adminDashboard");
    else if (path.startsWith("/admin/accounts")) groups.push("appCommon", "adminAccounts");
    else if (path.startsWith("/admin/users")) groups.push("appCommon", "adminUsers");
    else if (path.startsWith("/admin/groups")) groups.push("appCommon", "adminGroups");
    else if (path.startsWith("/admin/channels/monitor")) groups.push("appCommon", "adminMonitor");
    else if (path.startsWith("/admin/channels")) groups.push("appCommon", "adminChannels");
    else if (path.startsWith("/admin/settings")) groups.push("appCommon", "adminSettings");
    return Array.from(new Set(groups.flatMap((group) => routeAssets[group] || [])));
  }

  function prefetchPath(pathname, options = {}) {
    const urls = assetsForPath(pathname);
    enqueue(urls, options.reason || "route", Boolean(options.immediate));
  }

  function linkPathFromEvent(event) {
    const target = event.target && event.target.closest ? event.target.closest("a[href]") : null;
    if (!target) return "";
    const raw = target.getAttribute("href") || "";
    if (!raw || raw.startsWith("#") || raw.startsWith("mailto:") || raw.startsWith("tel:")) return "";
    try {
      const url = new URL(raw, location.href);
      if (url.origin !== location.origin) return "";
      return url.pathname;
    } catch {
      return "";
    }
  }

  ["pointerover", "focusin", "touchstart", "mousedown"].forEach((eventName) => {
    document.addEventListener(eventName, (event) => {
      const pathname = linkPathFromEvent(event);
      if (!pathname) return;
      prefetchPath(pathname, { reason: eventName, immediate: eventName === "mousedown" || eventName === "touchstart" });
    }, { capture: true, passive: true });
  });

  window.__LK_PREFETCH_ROUTE = prefetchPath;
})();
