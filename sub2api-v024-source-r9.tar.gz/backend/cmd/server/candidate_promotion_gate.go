package main

import (
	"log"
	"os"
	"sync"
)

// startCandidatePromotionLoop serializes promotion with shutdown. Its returned
// stop function waits for an in-flight promotion, then rejects all queued or
// future signals before application cleanup can stop shared workers.
func startCandidatePromotionLoop(promote <-chan os.Signal, promoteRuntimes func() (int, error)) func() {
	stop := make(chan struct{})
	done := make(chan struct{})
	var lifecycleMu sync.Mutex
	var stopping bool
	var stopOnce sync.Once

	go func() {
		defer close(done)
		for {
			select {
			case <-stop:
				return
			case <-promote:
			}

			lifecycleMu.Lock()
			if stopping {
				lifecycleMu.Unlock()
				continue
			}
			started, err := promoteRuntimes()
			lifecycleMu.Unlock()
			if err != nil {
				log.Printf("Candidate background runtime promotion failed: %v", err)
				continue
			}
			log.Printf("Candidate background runtimes promoted: %d", started)
		}
	}()

	return func() {
		stopOnce.Do(func() {
			lifecycleMu.Lock()
			stopping = true
			lifecycleMu.Unlock()
			close(stop)
			<-done
		})
	}
}

// startCandidatePromotionAbortLoop disables promotion without stopping the HTTP
// server. The release waits for its acknowledgement before reviving the old
// instance, closing the gap where a buffered SIGUSR1 could start consumers.
func startCandidatePromotionAbortLoop(abort <-chan os.Signal, stopPromotion func(), onAborted func()) func() {
	stop := make(chan struct{})
	done := make(chan struct{})
	var stopOnce sync.Once

	go func() {
		defer close(done)
		select {
		case <-stop:
			return
		case <-abort:
			if stopPromotion != nil {
				stopPromotion()
			}
			if onAborted != nil {
				onAborted()
			}
		}
	}()

	return func() {
		stopOnce.Do(func() {
			close(stop)
			<-done
		})
	}
}
