//go:build !windows

package main

import (
	"log"
	"os"
	"os/signal"
	"syscall"

	"github.com/Wei-Shaw/sub2api/internal/config"
	"github.com/Wei-Shaw/sub2api/internal/service"
)

// installCandidatePromotionSignal keeps shared consumers paused in a
// loopback-only candidate until the release procedure has switched traffic,
// drained the old instance, and explicitly sends SIGUSR1. SIGUSR2 disables a
// pending promotion during rollback while keeping the HTTP server available.
func installCandidatePromotionSignal() func() {
	if !config.IsCandidateRuntime() {
		return func() {}
	}
	aborted, err := config.CandidateRuntimePromotionAborted()
	if err != nil {
		log.Printf("Candidate background runtime promotion disabled because the durable abort marker is invalid: %v", err)
		return func() {}
	}
	if aborted {
		log.Println("Candidate background runtime promotion disabled by durable abort marker")
		return func() {}
	}
	promote := make(chan os.Signal, 1)
	abort := make(chan os.Signal, 1)
	signal.Notify(promote, syscall.SIGUSR1)
	signal.Notify(abort, syscall.SIGUSR2)
	stopLoop := startCandidatePromotionLoop(promote, service.PromoteCandidateBackgroundRuntimes)
	stopAbortLoop := startCandidatePromotionAbortLoop(abort, stopLoop, func() {
		// This is emitted only after an in-flight promotion has completed and
		// the loop will reject every future SIGUSR1 and the rollback fence is
		// atomically published for process/container restarts.
		if err := config.MarkCandidateRuntimePromotionAborted(); err != nil {
			log.Printf("Candidate background runtime promotion abort acknowledgement failed: %v", err)
			return
		}
		log.Println("Candidate background runtime promotion disabled")
	})
	log.Println("Candidate background runtimes are paused; send SIGUSR1 only after cutover and old-instance drain")
	return func() {
		// Mark the loop stopped before unregistering the signal, so a buffered
		// SIGUSR1 cannot start a runtime while application cleanup is underway.
		stopLoop()
		signal.Stop(promote)
		stopAbortLoop()
		signal.Stop(abort)
	}
}
