//go:build windows

package main

// Windows has no SIGUSR1. Production candidates run on Linux; this stub keeps
// local Windows builds portable.
func installCandidatePromotionSignal() func() { return func() {} }
