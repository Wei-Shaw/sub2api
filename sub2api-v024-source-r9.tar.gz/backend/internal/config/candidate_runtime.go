// Ported from 7b520f650:backend/internal/config/config.go.
package config

import (
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"runtime"
	"strings"
)

// CandidateRuntimeEnv keeps isolated release candidates from starting shared
// background consumers before Nginx has switched traffic to them.
const CandidateRuntimeEnv = "LUCHIKEY_CANDIDATE_MODE"

// CandidateRuntimePromotionMarkerEnv names a container-local regular file that
// marks a candidate as promoted. It must not point into a shared data volume:
// the marker belongs to one Docker container and survives only restarts of that
// same container.
const CandidateRuntimePromotionMarkerEnv = "LUCHIKEY_CANDIDATE_PROMOTION_MARKER"

// CandidateRuntimePromotionAbortMarkerEnv names a container-local regular
// file that records a rollback fence after SIGUSR2 has stopped the candidate's
// promotion loop. It must not point into a shared data volume.
const CandidateRuntimePromotionAbortMarkerEnv = "LUCHIKEY_CANDIDATE_PROMOTION_ABORT_MARKER"

const (
	candidateRuntimePromotionMarkerContents                  = "promoted-v3\n"
	candidateRuntimePromotionAbortMarkerContents             = "aborted-v1\n"
	candidateRuntimePromotionAbortConfirmationMarkerContents = "abort-confirmed-v1\n"
)

// IsCandidateRuntimeConfigured reports whether this process was launched as a
// release candidate, regardless of whether that candidate has since promoted.
func IsCandidateRuntimeConfigured() bool {
	switch strings.ToLower(strings.TrimSpace(os.Getenv(CandidateRuntimeEnv))) {
	case "1", "true", "yes":
		return true
	default:
		return false
	}
}

// IsCandidateRuntime reports whether this process must defer shared consumers.
// A valid marker is published only by the final atomic rename of an explicit
// promotion, so a restarted promoted candidate resumes normal consumers.
func IsCandidateRuntime() bool {
	if !IsCandidateRuntimeConfigured() {
		return false
	}
	aborted, err := CandidateRuntimePromotionAborted()
	if err != nil || aborted {
		return true
	}
	marker := strings.TrimSpace(os.Getenv(CandidateRuntimePromotionMarkerEnv))
	if marker == "" {
		return true
	}
	_, promoted, err := candidateRuntimePromotionMarkerStatus(marker)
	return err != nil || !promoted
}

// CandidateRuntimePromotionAborted reports whether a durable rollback fence
// prevents this candidate from being promoted. A malformed or unreadable
// configured marker is deliberately treated as aborted so a restart cannot
// revive shared consumers after rollback has started.
func CandidateRuntimePromotionAborted() (bool, error) {
	if !IsCandidateRuntimeConfigured() {
		return false, nil
	}

	marker := strings.TrimSpace(os.Getenv(CandidateRuntimePromotionAbortMarkerEnv))
	if marker == "" {
		return false, nil
	}
	if !filepath.IsAbs(marker) {
		return true, fmt.Errorf("%s must be an absolute path", CandidateRuntimePromotionAbortMarkerEnv)
	}
	exists, aborted, err := candidateRuntimePromotionAbortMarkerStatus(marker)
	if err != nil {
		return true, fmt.Errorf("inspect candidate promotion abort marker: %w", err)
	}
	if exists && !aborted {
		return true, fmt.Errorf("candidate promotion abort marker has invalid contents: %s", marker)
	}
	return exists && aborted, nil
}

// CandidateRuntimePromotionAbortConfirmed reports whether the durable abort
// marker and a post-durability confirmation are both present. The confirmation
// is written only after the primary marker has completed its final directory
// sync, so a visible primary marker from that uncertain failure window keeps
// the candidate paused but cannot enable stream-preserving rollback.
func CandidateRuntimePromotionAbortConfirmed() (bool, error) {
	aborted, err := CandidateRuntimePromotionAborted()
	if err != nil || !aborted {
		return false, err
	}

	marker, err := candidateRuntimePromotionAbortConfirmationMarkerPath()
	if err != nil {
		return false, err
	}
	exists, confirmed, err := candidateRuntimeMarkerStatusWith(
		marker,
		candidateRuntimePromotionAbortConfirmationMarkerContents,
		"candidate promotion abort confirmation marker",
	)
	if err != nil {
		return false, fmt.Errorf("inspect candidate promotion abort confirmation marker: %w", err)
	}
	if exists && !confirmed {
		return false, fmt.Errorf("candidate promotion abort confirmation marker has invalid contents: %s", marker)
	}
	return exists && confirmed, nil
}

// MarkCandidateRuntimePromoted records promotion before deferred consumers
// start. The marker is intentionally a regular file in the candidate's
// writable layer, never a shared database or mounted application-data volume.
func MarkCandidateRuntimePromoted() error {
	if !IsCandidateRuntimeConfigured() {
		return nil
	}

	aborted, err := CandidateRuntimePromotionAborted()
	if err != nil {
		return err
	}
	if aborted {
		return fmt.Errorf("candidate promotion is disabled by a durable abort marker")
	}
	marker, err := candidateRuntimeMarkerPath(CandidateRuntimePromotionMarkerEnv)
	if err != nil {
		return err
	}
	return markCandidateRuntimePromotedWith(marker, syncCandidateRuntimePromotionMarkerParent, createCandidateRuntimePromotionTempFile, os.Rename)
}

// MarkCandidateRuntimePromotionAborted publishes a durable rollback fence
// after the candidate promotion loop has stopped. It refuses to overwrite a
// committed promotion because that candidate may already own shared workers.
func MarkCandidateRuntimePromotionAborted() error {
	if !IsCandidateRuntimeConfigured() {
		return nil
	}

	marker, err := candidateRuntimeMarkerPath(CandidateRuntimePromotionAbortMarkerEnv)
	if err != nil {
		return err
	}
	promotionMarker := strings.TrimSpace(os.Getenv(CandidateRuntimePromotionMarkerEnv))
	if promotionMarker != "" {
		if !filepath.IsAbs(promotionMarker) {
			return fmt.Errorf("%s must be an absolute path", CandidateRuntimePromotionMarkerEnv)
		}
		exists, promoted, err := candidateRuntimePromotionMarkerStatus(promotionMarker)
		if err != nil {
			return fmt.Errorf("inspect candidate promotion marker: %w", err)
		}
		if exists {
			if promoted {
				return fmt.Errorf("candidate promotion is already committed")
			}
			return fmt.Errorf("candidate promotion marker has invalid contents: %s", promotionMarker)
		}
	}
	confirmationMarker, err := candidateRuntimePromotionAbortConfirmationMarkerPath()
	if err != nil {
		return err
	}
	return markCandidateRuntimePromotionAbortedAndConfirmedWith(
		marker,
		confirmationMarker,
		syncCandidateRuntimePromotionMarkerParent,
		createCandidateRuntimePromotionTempFile,
		os.Rename,
	)
}

func candidateRuntimeMarkerPath(env string) (string, error) {
	marker := strings.TrimSpace(os.Getenv(env))
	if marker == "" {
		return "", fmt.Errorf("%s is required when %s is enabled", env, CandidateRuntimeEnv)
	}
	if !filepath.IsAbs(marker) {
		return "", fmt.Errorf("%s must be an absolute path", env)
	}
	return marker, nil
}

func candidateRuntimePromotionAbortConfirmationMarkerPath() (string, error) {
	marker, err := candidateRuntimeMarkerPath(CandidateRuntimePromotionAbortMarkerEnv)
	if err != nil {
		return "", err
	}
	return marker + ".confirmed", nil
}

type candidateRuntimePromotionTempFile interface {
	WriteString(string) (int, error)
	Sync() error
	Close() error
	Name() string
}

type candidateRuntimePromotionTempFileCreator func(parent, pattern string) (candidateRuntimePromotionTempFile, error)

type candidateRuntimePromotionRenamer func(oldPath, newPath string) error

func markCandidateRuntimePromotedWith(
	marker string,
	syncParent func(string) error,
	createTemp candidateRuntimePromotionTempFileCreator,
	renameFile candidateRuntimePromotionRenamer,
) error {
	return markCandidateRuntimeMarkerWith(
		marker,
		candidateRuntimePromotionMarkerContents,
		"candidate promotion marker",
		"promotion",
		false,
		candidateRuntimePromotionMarkerStatus,
		syncParent,
		createTemp,
		renameFile,
	)
}

func markCandidateRuntimePromotionAbortedWith(
	marker string,
	syncParent func(string) error,
	createTemp candidateRuntimePromotionTempFileCreator,
	renameFile candidateRuntimePromotionRenamer,
) error {
	return markCandidateRuntimeMarkerWith(
		marker,
		candidateRuntimePromotionAbortMarkerContents,
		"candidate promotion abort marker",
		"abort",
		true,
		candidateRuntimePromotionAbortMarkerStatus,
		syncParent,
		createTemp,
		renameFile,
	)
}

func markCandidateRuntimePromotionAbortedAndConfirmedWith(
	marker string,
	confirmationMarker string,
	syncParent func(string) error,
	createTemp candidateRuntimePromotionTempFileCreator,
	renameFile candidateRuntimePromotionRenamer,
) error {
	if err := markCandidateRuntimePromotionAbortedWith(marker, syncParent, createTemp, renameFile); err != nil {
		return err
	}
	// This acknowledgement is attempted only after the primary marker has
	// completed all durability checks. Its presence is therefore a reliable
	// release-side distinction from a visible-but-uncertain primary marker.
	return markCandidateRuntimePromotionAbortConfirmedWith(confirmationMarker, syncParent, createTemp, renameFile)
}

func markCandidateRuntimePromotionAbortConfirmedWith(
	marker string,
	syncParent func(string) error,
	createTemp candidateRuntimePromotionTempFileCreator,
	renameFile candidateRuntimePromotionRenamer,
) error {
	return markCandidateRuntimeMarkerWith(
		marker,
		candidateRuntimePromotionAbortConfirmationMarkerContents,
		"candidate promotion abort confirmation marker",
		"abort-confirmed",
		true,
		func(path string) (bool, bool, error) {
			return candidateRuntimeMarkerStatusWith(
				path,
				candidateRuntimePromotionAbortConfirmationMarkerContents,
				"candidate promotion abort confirmation marker",
			)
		},
		syncParent,
		createTemp,
		renameFile,
	)
}

type candidateRuntimeMarkerStatus func(marker string) (exists, valid bool, err error)

func markCandidateRuntimeMarkerWith(
	marker string,
	contents string,
	label string,
	tempSuffix string,
	failOnPostPublishSync bool,
	status candidateRuntimeMarkerStatus,
	syncParent func(string) error,
	createTemp candidateRuntimePromotionTempFileCreator,
	renameFile candidateRuntimePromotionRenamer,
) error {
	if syncParent == nil {
		return fmt.Errorf("%s parent sync is unavailable", label)
	}
	if createTemp == nil {
		return fmt.Errorf("%s temp file creator is unavailable", label)
	}
	if renameFile == nil {
		return fmt.Errorf("%s renamer is unavailable", label)
	}

	exists, valid, err := status(marker)
	if err != nil {
		return fmt.Errorf("inspect %s: %w", label, err)
	}
	if exists {
		if valid {
			return nil
		}
		return fmt.Errorf("%s has invalid contents: %s", label, marker)
	}

	parent := filepath.Dir(marker)
	tempFile, err := createTemp(parent, "."+filepath.Base(marker)+"."+tempSuffix+"-*")
	if err != nil {
		return fmt.Errorf("create %s temp file: %w", label, err)
	}
	tempPath := tempFile.Name()
	removeTemp := true
	defer func() {
		if removeTemp {
			_ = os.Remove(tempPath)
		}
	}()
	if _, err := tempFile.WriteString(contents); err != nil {
		_ = tempFile.Close()
		return fmt.Errorf("write %s temp file: %w", label, err)
	}
	if err := tempFile.Sync(); err != nil {
		_ = tempFile.Close()
		return fmt.Errorf("sync %s temp file: %w", label, err)
	}
	if err := tempFile.Close(); err != nil {
		return fmt.Errorf("close %s temp file: %w", label, err)
	}
	if err := syncParent(parent); err != nil {
		return fmt.Errorf("sync %s temp parent: %w", label, err)
	}

	// Rename is the commit point. A reported rename error may still leave a
	// visible marker, so verify it and complete the normal post-publish sync.
	if err := renameFile(tempPath, marker); err != nil {
		_, valid, statusErr := status(marker)
		if statusErr != nil || !valid {
			return fmt.Errorf("publish %s: %w", label, err)
		}
	}
	removeTemp = false
	if err := syncParent(parent); err != nil {
		// The marker content was synced before the atomic rename. A later
		// directory-sync error is durability-uncertain. Promotion may tolerate
		// that because its absence remains fail-closed; an abort must report it
		// because a missing abort marker would permit a later promotion.
		if failOnPostPublishSync {
			return fmt.Errorf("sync %s parent after publish: %w", label, err)
		}
		slog.Warn(label+" parent sync after publish failed", "error", err)
	}
	return nil
}

func createCandidateRuntimePromotionTempFile(parent, pattern string) (candidateRuntimePromotionTempFile, error) {
	return os.CreateTemp(parent, pattern)
}

func candidateRuntimePromotionMarkerStatus(marker string) (exists, promoted bool, err error) {
	return candidateRuntimeMarkerStatusWith(marker, candidateRuntimePromotionMarkerContents, "candidate promotion marker")
}

func candidateRuntimePromotionAbortMarkerStatus(marker string) (exists, aborted bool, err error) {
	return candidateRuntimeMarkerStatusWith(marker, candidateRuntimePromotionAbortMarkerContents, "candidate promotion abort marker")
}

func candidateRuntimeMarkerStatusWith(marker string, expectedContents string, label string) (exists, valid bool, err error) {
	info, err := os.Lstat(marker)
	if os.IsNotExist(err) {
		return false, false, nil
	}
	if err != nil {
		return false, false, err
	}
	if !info.Mode().IsRegular() {
		return true, false, fmt.Errorf("%s must be a regular file: %s", label, marker)
	}
	contents, err := os.ReadFile(marker)
	if err != nil {
		return true, false, err
	}
	return true, string(contents) == expectedContents, nil
}

func syncCandidateRuntimePromotionMarkerParent(path string) error {
	// Windows cannot fsync a directory. Production candidates run on Linux;
	// preserving a no-op keeps local Windows tests portable.
	if runtime.GOOS == "windows" {
		return nil
	}
	dir, err := os.Open(path)
	if err != nil {
		return err
	}
	defer func() { _ = dir.Close() }()
	return dir.Sync()
}
