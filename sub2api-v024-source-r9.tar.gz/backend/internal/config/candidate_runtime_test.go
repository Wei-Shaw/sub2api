package config

import (
	"errors"
	"os"
	"path/filepath"
	"testing"
)

func TestIsCandidateRuntime(t *testing.T) {
	t.Setenv(CandidateRuntimeEnv, "")
	t.Setenv(CandidateRuntimePromotionMarkerEnv, "")
	if IsCandidateRuntime() {
		t.Fatal("empty candidate runtime flag must be disabled")
	}

	for _, value := range []string{"true", "TRUE", "1", " yes "} {
		t.Run(value, func(t *testing.T) {
			t.Setenv(CandidateRuntimeEnv, value)
			if !IsCandidateRuntime() {
				t.Fatalf("%q must enable candidate runtime", value)
			}
		})
	}

	for _, value := range []string{"false", "0", "unexpected"} {
		t.Run(value, func(t *testing.T) {
			t.Setenv(CandidateRuntimeEnv, value)
			if IsCandidateRuntime() {
				t.Fatalf("%q must not enable candidate runtime", value)
			}
		})
	}
}

func TestCandidateRuntimePromotionMarkerSurvivesRestart(t *testing.T) {
	marker := filepath.Join(t.TempDir(), "candidate-promoted")
	t.Setenv(CandidateRuntimeEnv, "true")
	t.Setenv(CandidateRuntimePromotionMarkerEnv, marker)

	if !IsCandidateRuntime() {
		t.Fatal("candidate must pause consumers before promotion")
	}
	if err := MarkCandidateRuntimePromoted(); err != nil {
		t.Fatalf("mark candidate promoted: %v", err)
	}
	info, err := os.Lstat(marker)
	if err != nil {
		t.Fatalf("promotion marker missing: %v", err)
	}
	if !info.Mode().IsRegular() {
		t.Fatalf("promotion marker mode = %v, want regular file", info.Mode())
	}
	contents, err := os.ReadFile(marker)
	if err != nil {
		t.Fatalf("read promotion marker: %v", err)
	}
	if string(contents) != candidateRuntimePromotionMarkerContents {
		t.Fatalf("promotion marker contents = %q, want %q", contents, candidateRuntimePromotionMarkerContents)
	}
	if IsCandidateRuntime() {
		t.Fatal("a promoted candidate must resume consumers after a process restart")
	}
}

func TestCandidateRuntimePromotionAbortMarkerSurvivesRestartAndBlocksPromotion(t *testing.T) {
	dir := t.TempDir()
	promotionMarker := filepath.Join(dir, "candidate-promoted")
	abortMarker := filepath.Join(dir, "candidate-promotion-aborted")
	t.Setenv(CandidateRuntimeEnv, "true")
	t.Setenv(CandidateRuntimePromotionMarkerEnv, promotionMarker)
	t.Setenv(CandidateRuntimePromotionAbortMarkerEnv, abortMarker)

	if err := MarkCandidateRuntimePromotionAborted(); err != nil {
		t.Fatalf("mark candidate promotion aborted: %v", err)
	}
	info, err := os.Lstat(abortMarker)
	if err != nil {
		t.Fatalf("abort marker missing: %v", err)
	}
	if !info.Mode().IsRegular() {
		t.Fatalf("abort marker mode = %v, want regular file", info.Mode())
	}
	contents, err := os.ReadFile(abortMarker)
	if err != nil {
		t.Fatalf("read abort marker: %v", err)
	}
	if string(contents) != candidateRuntimePromotionAbortMarkerContents {
		t.Fatalf("abort marker contents = %q, want %q", contents, candidateRuntimePromotionAbortMarkerContents)
	}
	confirmationMarker := abortMarker + ".confirmed"
	confirmationContents, err := os.ReadFile(confirmationMarker)
	if err != nil {
		t.Fatalf("read abort confirmation marker: %v", err)
	}
	if string(confirmationContents) != candidateRuntimePromotionAbortConfirmationMarkerContents {
		t.Fatalf("abort confirmation marker contents = %q, want %q", confirmationContents, candidateRuntimePromotionAbortConfirmationMarkerContents)
	}
	aborted, err := CandidateRuntimePromotionAborted()
	if err != nil {
		t.Fatalf("inspect abort marker: %v", err)
	}
	if !aborted {
		t.Fatal("a durable abort marker must survive a candidate restart")
	}
	confirmed, err := CandidateRuntimePromotionAbortConfirmed()
	if err != nil {
		t.Fatalf("inspect abort confirmation marker: %v", err)
	}
	if !confirmed {
		t.Fatal("a fully durable abort must publish its confirmation marker")
	}
	if !IsCandidateRuntime() {
		t.Fatal("an aborted candidate must keep shared consumers paused after restart")
	}
	if err := MarkCandidateRuntimePromoted(); err == nil {
		t.Fatal("a durable abort marker must reject a later promotion")
	}
}

func TestCandidateRuntimePromotionAbortWithoutConfirmationStaysPausedButIsNotRollbackConfirmed(t *testing.T) {
	dir := t.TempDir()
	abortMarker := filepath.Join(dir, "candidate-promotion-aborted")
	t.Setenv(CandidateRuntimeEnv, "true")
	t.Setenv(CandidateRuntimePromotionMarkerEnv, filepath.Join(dir, "candidate-promoted"))
	t.Setenv(CandidateRuntimePromotionAbortMarkerEnv, abortMarker)
	if err := os.WriteFile(abortMarker, []byte(candidateRuntimePromotionAbortMarkerContents), 0o600); err != nil {
		t.Fatalf("write abort marker: %v", err)
	}

	confirmed, err := CandidateRuntimePromotionAbortConfirmed()
	if err != nil {
		t.Fatalf("inspect absent confirmation marker: %v", err)
	}
	if confirmed {
		t.Fatal("an abort without confirmation must not enable stream-preserving rollback")
	}
	if !IsCandidateRuntime() {
		t.Fatal("an unconfirmed abort marker must still keep shared consumers paused")
	}
}

func TestCandidateRuntimePromotionAbortConfirmationFailsClosedWhenMalformed(t *testing.T) {
	dir := t.TempDir()
	abortMarker := filepath.Join(dir, "candidate-promotion-aborted")
	t.Setenv(CandidateRuntimeEnv, "true")
	t.Setenv(CandidateRuntimePromotionMarkerEnv, filepath.Join(dir, "candidate-promoted"))
	t.Setenv(CandidateRuntimePromotionAbortMarkerEnv, abortMarker)
	if err := os.WriteFile(abortMarker, []byte(candidateRuntimePromotionAbortMarkerContents), 0o600); err != nil {
		t.Fatalf("write abort marker: %v", err)
	}
	if err := os.WriteFile(abortMarker+".confirmed", []byte("abort-confirmed-v0\n"), 0o600); err != nil {
		t.Fatalf("write malformed abort confirmation marker: %v", err)
	}

	confirmed, err := CandidateRuntimePromotionAbortConfirmed()
	if err == nil {
		t.Fatal("malformed abort confirmation marker must return an error")
	}
	if confirmed {
		t.Fatal("malformed abort confirmation marker must fail closed")
	}
	if !IsCandidateRuntime() {
		t.Fatal("a valid primary abort marker must keep the candidate isolated")
	}
}

func TestCandidateRuntimePromotionAbortMarkerFailsClosedWhenMalformed(t *testing.T) {
	dir := t.TempDir()
	t.Setenv(CandidateRuntimeEnv, "true")
	t.Setenv(CandidateRuntimePromotionMarkerEnv, filepath.Join(dir, "candidate-promoted"))
	abortMarker := filepath.Join(dir, "candidate-promotion-aborted")
	t.Setenv(CandidateRuntimePromotionAbortMarkerEnv, abortMarker)
	if err := os.WriteFile(abortMarker, []byte("aborted-v0\n"), 0o600); err != nil {
		t.Fatalf("write malformed abort marker: %v", err)
	}

	aborted, err := CandidateRuntimePromotionAborted()
	if err == nil {
		t.Fatal("malformed abort marker must return an error")
	}
	if !aborted {
		t.Fatal("malformed abort marker must fail closed")
	}
	if !IsCandidateRuntime() {
		t.Fatal("malformed abort marker must keep the candidate isolated")
	}
	if err := MarkCandidateRuntimePromoted(); err == nil {
		t.Fatal("malformed abort marker must reject a later promotion")
	}
}

func TestCandidateRuntimePromotionAbortCannotOverrideCommittedPromotion(t *testing.T) {
	dir := t.TempDir()
	t.Setenv(CandidateRuntimeEnv, "true")
	t.Setenv(CandidateRuntimePromotionMarkerEnv, filepath.Join(dir, "candidate-promoted"))
	t.Setenv(CandidateRuntimePromotionAbortMarkerEnv, filepath.Join(dir, "candidate-promotion-aborted"))
	if err := MarkCandidateRuntimePromoted(); err != nil {
		t.Fatalf("mark candidate promoted: %v", err)
	}
	if err := MarkCandidateRuntimePromotionAborted(); err == nil {
		t.Fatal("abort marker must not override an already committed promotion")
	}
	if IsCandidateRuntime() {
		t.Fatal("a committed candidate must preserve normal post-restart behavior")
	}
}

func TestMarkCandidateRuntimePromotionAbortedRequiresMarker(t *testing.T) {
	t.Setenv(CandidateRuntimeEnv, "true")
	t.Setenv(CandidateRuntimePromotionAbortMarkerEnv, "")
	if err := MarkCandidateRuntimePromotionAborted(); err == nil {
		t.Fatal("candidate promotion abort without a marker path must fail closed")
	}
}

func TestMarkCandidateRuntimePromotionAbortedRejectsUncertainDirectorySync(t *testing.T) {
	marker := filepath.Join(t.TempDir(), "candidate-promotion-aborted")
	postPublishSyncErr := errors.New("post-publish directory sync")
	syncCalls := 0

	err := markCandidateRuntimePromotionAbortedWith(marker, func(string) error {
		syncCalls++
		if syncCalls == 2 {
			return postPublishSyncErr
		}
		return nil
	}, createCandidateRuntimePromotionTempFile, os.Rename)
	if !errors.Is(err, postPublishSyncErr) {
		t.Fatalf("abort error = %v, want post-publish directory sync error", err)
	}
	if syncCalls != 2 {
		t.Fatalf("parent sync calls = %d, want 2", syncCalls)
	}
	if _, statErr := os.Lstat(marker); statErr != nil {
		t.Fatalf("marker must remain visible for fail-closed inspection, stat error = %v", statErr)
	}
}

func TestMarkCandidateRuntimePromotionAbortedDoesNotConfirmUncertainPrimarySync(t *testing.T) {
	dir := t.TempDir()
	marker := filepath.Join(dir, "candidate-promotion-aborted")
	confirmationMarker := marker + ".confirmed"
	postPublishSyncErr := errors.New("post-publish directory sync")
	syncCalls := 0

	err := markCandidateRuntimePromotionAbortedAndConfirmedWith(
		marker,
		confirmationMarker,
		func(string) error {
			syncCalls++
			if syncCalls == 2 {
				return postPublishSyncErr
			}
			return nil
		},
		createCandidateRuntimePromotionTempFile,
		os.Rename,
	)
	if !errors.Is(err, postPublishSyncErr) {
		t.Fatalf("abort error = %v, want post-publish directory sync error", err)
	}
	if syncCalls != 2 {
		t.Fatalf("parent sync calls = %d, want 2", syncCalls)
	}
	if _, statErr := os.Lstat(marker); statErr != nil {
		t.Fatalf("primary abort marker must remain visible for fail-closed inspection, stat error = %v", statErr)
	}
	if _, statErr := os.Lstat(confirmationMarker); !os.IsNotExist(statErr) {
		t.Fatalf("uncertain primary abort must not publish confirmation marker, stat error = %v", statErr)
	}
}

func TestMarkCandidateRuntimePromotionAbortedSyncsVisibleMarkerAfterRenameError(t *testing.T) {
	marker := filepath.Join(t.TempDir(), "candidate-promotion-aborted")
	renameErr := errors.New("rename status uncertain")
	postPublishSyncErr := errors.New("post-publish directory sync")
	syncCalls := 0

	err := markCandidateRuntimePromotionAbortedWith(marker, func(string) error {
		syncCalls++
		if syncCalls == 2 {
			return postPublishSyncErr
		}
		return nil
	}, createCandidateRuntimePromotionTempFile, func(oldPath, newPath string) error {
		if err := os.Rename(oldPath, newPath); err != nil {
			t.Fatalf("perform atomic publish: %v", err)
		}
		return renameErr
	})
	if !errors.Is(err, postPublishSyncErr) {
		t.Fatalf("abort error = %v, want post-publish directory sync error", err)
	}
	if syncCalls != 2 {
		t.Fatalf("parent sync calls = %d, want 2", syncCalls)
	}
	if _, statErr := os.Lstat(marker); statErr != nil {
		t.Fatalf("marker must remain visible after rename uncertainty, stat error = %v", statErr)
	}
}

func TestCandidateRuntimeDoesNotTrustInvalidPromotionMarker(t *testing.T) {
	marker := filepath.Join(t.TempDir(), "candidate-promoted")
	t.Setenv(CandidateRuntimeEnv, "true")
	t.Setenv(CandidateRuntimePromotionMarkerEnv, marker)
	if err := os.WriteFile(marker, []byte("promoted-v2\n"), 0o600); err != nil {
		t.Fatalf("write legacy marker: %v", err)
	}

	if !IsCandidateRuntime() {
		t.Fatal("an invalid marker must keep the candidate isolated")
	}
	if err := MarkCandidateRuntimePromoted(); err == nil {
		t.Fatal("invalid marker must not be silently promoted")
	}
	if !IsCandidateRuntime() {
		t.Fatal("invalid marker must keep the candidate isolated after a failed signal")
	}
}

func TestMarkCandidateRuntimePromotedRequiresMarker(t *testing.T) {
	t.Setenv(CandidateRuntimeEnv, "true")
	t.Setenv(CandidateRuntimePromotionMarkerEnv, "")
	if err := MarkCandidateRuntimePromoted(); err == nil {
		t.Fatal("candidate promotion without a marker path must fail closed")
	}
}

func TestMarkCandidateRuntimePromotedFailsClosedBeforeAtomicPublish(t *testing.T) {
	marker := filepath.Join(t.TempDir(), "candidate-promoted")
	t.Setenv(CandidateRuntimeEnv, "true")
	t.Setenv(CandidateRuntimePromotionMarkerEnv, marker)
	syncErr := errors.New("sync temp marker parent")

	err := markCandidateRuntimePromotedWith(marker, func(path string) error {
		if path != filepath.Dir(marker) {
			t.Fatalf("synced parent = %q, want %q", path, filepath.Dir(marker))
		}
		return syncErr
	}, createCandidateRuntimePromotionTempFile, os.Rename)
	if !errors.Is(err, syncErr) {
		t.Fatalf("promotion error = %v, want temp parent sync error", err)
	}
	if _, statErr := os.Lstat(marker); !os.IsNotExist(statErr) {
		t.Fatalf("marker must not be published before the parent sync, stat error = %v", statErr)
	}
	if !IsCandidateRuntime() {
		t.Fatal("a pre-publish failure must keep the runtime in candidate mode")
	}
}

func TestMarkCandidateRuntimePromotedFailsClosedWhenAtomicPublishFails(t *testing.T) {
	marker := filepath.Join(t.TempDir(), "candidate-promoted")
	t.Setenv(CandidateRuntimeEnv, "true")
	t.Setenv(CandidateRuntimePromotionMarkerEnv, marker)
	publishErr := errors.New("atomic publish failed")

	err := markCandidateRuntimePromotedWith(marker, func(string) error { return nil }, createCandidateRuntimePromotionTempFile, func(string, string) error {
		return publishErr
	})
	if !errors.Is(err, publishErr) {
		t.Fatalf("promotion error = %v, want atomic publish error", err)
	}
	if _, statErr := os.Lstat(marker); !os.IsNotExist(statErr) {
		t.Fatalf("marker must not exist after failed publish, stat error = %v", statErr)
	}
	if !IsCandidateRuntime() {
		t.Fatal("a failed publish must keep the runtime in candidate mode")
	}
}

func TestMarkCandidateRuntimePromotedTreatsVisibleMarkerAfterRenameErrorAsCommitted(t *testing.T) {
	marker := filepath.Join(t.TempDir(), "candidate-promoted")
	t.Setenv(CandidateRuntimeEnv, "true")
	t.Setenv(CandidateRuntimePromotionMarkerEnv, marker)
	renameErr := errors.New("rename status uncertain")

	err := markCandidateRuntimePromotedWith(marker, func(string) error { return nil }, createCandidateRuntimePromotionTempFile, func(oldPath, newPath string) error {
		if err := os.Rename(oldPath, newPath); err != nil {
			t.Fatalf("perform atomic publish: %v", err)
		}
		return renameErr
	})
	if err != nil {
		t.Fatalf("a visible valid marker must be treated as committed, got %v", err)
	}
	if IsCandidateRuntime() {
		t.Fatal("a committed marker must resume consumers after restart")
	}
}

func TestMarkCandidateRuntimePromotedTempFileFailuresStayIsolated(t *testing.T) {
	for _, phase := range []string{"write", "sync", "close"} {
		t.Run(phase, func(t *testing.T) {
			marker := filepath.Join(t.TempDir(), "candidate-promoted")
			t.Setenv(CandidateRuntimeEnv, "true")
			t.Setenv(CandidateRuntimePromotionMarkerEnv, marker)
			failure := errors.New("injected " + phase + " failure")

			err := markCandidateRuntimePromotedWith(marker, func(string) error { return nil }, func(parent, pattern string) (candidateRuntimePromotionTempFile, error) {
				file, err := os.CreateTemp(parent, pattern)
				if err != nil {
					return nil, err
				}
				return &failingCandidateRuntimePromotionTempFile{file: file, phase: phase, failure: failure}, nil
			}, os.Rename)
			if !errors.Is(err, failure) {
				t.Fatalf("promotion error = %v, want injected failure", err)
			}
			if _, statErr := os.Lstat(marker); !os.IsNotExist(statErr) {
				t.Fatalf("marker must not exist after %s failure, stat error = %v", phase, statErr)
			}
			if !IsCandidateRuntime() {
				t.Fatalf("a %s failure must keep the runtime in candidate mode", phase)
			}
		})
	}
}

func TestMarkCandidateRuntimePromotedDoesNotReturnFailureAfterPublish(t *testing.T) {
	marker := filepath.Join(t.TempDir(), "candidate-promoted")
	t.Setenv(CandidateRuntimeEnv, "true")
	t.Setenv(CandidateRuntimePromotionMarkerEnv, marker)
	postPublishSyncErr := errors.New("post-publish directory sync")
	syncCalls := 0

	err := markCandidateRuntimePromotedWith(marker, func(string) error {
		syncCalls++
		if syncCalls == 2 {
			return postPublishSyncErr
		}
		return nil
	}, createCandidateRuntimePromotionTempFile, os.Rename)
	if err != nil {
		t.Fatalf("post-publish sync must not return a failed promotion: %v", err)
	}
	if syncCalls != 2 {
		t.Fatalf("parent sync calls = %d, want 2", syncCalls)
	}
	if IsCandidateRuntime() {
		t.Fatal("a published marker must resume consumers after restart")
	}
}

type failingCandidateRuntimePromotionTempFile struct {
	file    *os.File
	phase   string
	failure error
}

func (f *failingCandidateRuntimePromotionTempFile) Name() string {
	return f.file.Name()
}

func (f *failingCandidateRuntimePromotionTempFile) WriteString(contents string) (int, error) {
	n, err := f.file.WriteString(contents)
	if err != nil || f.phase != "write" {
		return n, err
	}
	return n, f.failure
}

func (f *failingCandidateRuntimePromotionTempFile) Sync() error {
	err := f.file.Sync()
	if err != nil || f.phase != "sync" {
		return err
	}
	return f.failure
}

func (f *failingCandidateRuntimePromotionTempFile) Close() error {
	err := f.file.Close()
	if err != nil || f.phase != "close" {
		return err
	}
	return f.failure
}
