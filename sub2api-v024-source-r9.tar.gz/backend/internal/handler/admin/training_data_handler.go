package admin

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/Wei-Shaw/sub2api/internal/pkg/pagination"
	"github.com/Wei-Shaw/sub2api/internal/pkg/response"
	"github.com/Wei-Shaw/sub2api/internal/pkg/timezone"
	"github.com/Wei-Shaw/sub2api/internal/service"

	"github.com/gin-gonic/gin"
)

type TrainingDataHandler struct {
	service *service.TrainingDataService
}

type updateTrainingPreferenceRequest struct {
	CaptureEnabled *bool `json:"capture_enabled" binding:"required"`
}

type trainingDataExportRecord struct {
	Messages  json.RawMessage `json:"messages"`
	Metadata  map[string]any  `json:"metadata"`
	CreatedAt time.Time       `json:"created_at"`
}

func NewTrainingDataHandler(service *service.TrainingDataService) *TrainingDataHandler {
	return &TrainingDataHandler{service: service}
}

func (h *TrainingDataHandler) List(c *gin.Context) {
	filter, params, ok := parseTrainingDataQuery(c)
	if !ok {
		return
	}
	items, page, err := h.service.List(c.Request.Context(), filter, params)
	if err != nil {
		response.InternalError(c, "Failed to list training data")
		return
	}
	response.Success(c, response.PaginatedData{
		Items:    items,
		Total:    page.Total,
		Page:     page.Page,
		PageSize: page.PageSize,
		Pages:    page.Pages,
	})
}

func (h *TrainingDataHandler) Summary(c *gin.Context) {
	userTZ := strings.TrimSpace(c.Query("timezone"))
	if userTZ != "" {
		if _, err := time.LoadLocation(userTZ); err != nil {
			response.BadRequest(c, "Invalid timezone")
			return
		}
	}
	start := timezone.StartOfDayInUserLocation(time.Now(), userTZ)
	if raw := strings.TrimSpace(c.Query("date")); raw != "" {
		parsed, err := timezone.ParseInUserLocation("2006-01-02", raw, userTZ)
		if err != nil {
			response.BadRequest(c, "Invalid date format, use YYYY-MM-DD")
			return
		}
		start = parsed
	}
	days := 1
	if raw := strings.TrimSpace(c.Query("days")); raw != "" {
		parsed, err := strconv.Atoi(raw)
		if err != nil || parsed < 1 || parsed > 31 {
			response.BadRequest(c, "Invalid days, use 1-31")
			return
		}
		days = parsed
	}

	summary, err := h.service.SummaryDays(c.Request.Context(), start, days)
	if err != nil {
		response.InternalError(c, "Failed to summarize training data")
		return
	}
	if summary == nil {
		summary = &service.TrainingDataSummary{TodayDate: start.Format("2006-01-02")}
	}
	response.Success(c, summary)
}

func (h *TrainingDataHandler) Export(c *gin.Context) {
	filter, _, ok := parseTrainingDataQuery(c)
	if !ok {
		return
	}
	limit := service.TrainingDataMaxExportRows
	if raw := strings.TrimSpace(c.Query("limit")); raw != "" {
		parsed, err := strconv.Atoi(raw)
		if err != nil || parsed <= 0 {
			response.BadRequest(c, "Invalid limit")
			return
		}
		limit = parsed
	}

	items, err := h.service.Export(c.Request.Context(), filter, limit)
	if err != nil {
		response.InternalError(c, "Failed to export training data")
		return
	}

	filename := fmt.Sprintf("training-data-%s.ndjson", time.Now().Format("20060102T150405"))
	c.Header("Content-Type", "application/x-ndjson; charset=utf-8")
	c.Header("Content-Disposition", fmt.Sprintf(`attachment; filename="%s"`, filename))
	c.Status(http.StatusOK)
	enc := json.NewEncoder(c.Writer)
	for i := range items {
		if err := enc.Encode(trainingDataExportRecordFromConversation(items[i])); err != nil {
			return
		}
	}
}

func trainingDataExportRecordFromConversation(item service.TrainingConversation) trainingDataExportRecord {
	metadata := map[string]any{}
	if raw := bytes.TrimSpace(item.Metadata); len(raw) > 0 {
		_ = json.Unmarshal(raw, &metadata)
	}
	if _, ok := metadata["tools"]; !ok {
		if tools, ok := metadata["tool_definitions"]; ok {
			metadata["tools"] = tools
		}
	}
	if _, ok := metadata["model"]; !ok && item.Model != "" {
		if sourceModel, ok := metadata["source_model"].(string); ok && strings.TrimSpace(sourceModel) != "" {
			metadata["model"] = strings.TrimSpace(sourceModel)
		} else {
			metadata["model"] = item.Model
		}
	}
	if _, ok := metadata["full_dedup_hash"]; !ok && item.RequestHash != "" {
		metadata["full_dedup_hash"] = item.RequestHash
	}

	messages := json.RawMessage(`[]`)
	if raw := bytes.TrimSpace(item.UserInput); len(raw) > 0 {
		messages = append(json.RawMessage(nil), raw...)
	}
	return trainingDataExportRecord{
		Messages:  messages,
		Metadata:  metadata,
		CreatedAt: item.CreatedAt,
	}
}

func (h *TrainingDataHandler) GetUserPreference(c *gin.Context) {
	userID, ok := parseTrainingDataUserIDParam(c)
	if !ok {
		return
	}
	preference, err := h.service.GetUserPreference(c.Request.Context(), userID)
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	response.Success(c, preference)
}

func (h *TrainingDataHandler) UpdateUserPreference(c *gin.Context) {
	userID, ok := parseTrainingDataUserIDParam(c)
	if !ok {
		return
	}

	var req updateTrainingPreferenceRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, "Invalid request: "+err.Error())
		return
	}
	if req.CaptureEnabled == nil {
		response.BadRequest(c, "capture_enabled is required")
		return
	}

	preference, err := h.service.SetUserCaptureEnabled(c.Request.Context(), userID, *req.CaptureEnabled)
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	response.Success(c, preference)
}

func parseTrainingDataUserIDParam(c *gin.Context) (int64, bool) {
	id, err := strconv.ParseInt(strings.TrimSpace(c.Param("id")), 10, 64)
	if err != nil || id <= 0 {
		response.BadRequest(c, "Invalid user ID")
		return 0, false
	}
	return id, true
}

func parseTrainingDataQuery(c *gin.Context) (service.TrainingDataFilter, pagination.PaginationParams, bool) {
	page, pageSize := response.ParsePagination(c)
	params := pagination.PaginationParams{
		Page:      page,
		PageSize:  pageSize,
		SortOrder: c.Query("sort_order"),
	}
	filter := service.TrainingDataFilter{
		Model:     strings.TrimSpace(c.Query("model")),
		Protocol:  strings.TrimSpace(c.Query("protocol")),
		SortOrder: params.SortOrder,
	}

	if raw := strings.TrimSpace(c.Query("user_id")); raw != "" {
		id, err := strconv.ParseInt(raw, 10, 64)
		if err != nil || id <= 0 {
			response.BadRequest(c, "Invalid user_id")
			return filter, params, false
		}
		filter.UserID = &id
	}

	userTZ := c.Query("timezone")
	if raw := strings.TrimSpace(c.Query("start_date")); raw != "" {
		t, err := timezone.ParseInUserLocation("2006-01-02", raw, userTZ)
		if err != nil {
			response.BadRequest(c, "Invalid start_date format, use YYYY-MM-DD")
			return filter, params, false
		}
		filter.StartTime = &t
	}
	if raw := strings.TrimSpace(c.Query("end_date")); raw != "" {
		t, err := timezone.ParseInUserLocation("2006-01-02", raw, userTZ)
		if err != nil {
			response.BadRequest(c, "Invalid end_date format, use YYYY-MM-DD")
			return filter, params, false
		}
		end := t.AddDate(0, 0, 1)
		filter.EndTime = &end
	}

	return filter, params, true
}
