package admin

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/Wei-Shaw/sub2api/internal/pkg/pagination"
	"github.com/Wei-Shaw/sub2api/internal/service"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/require"
)

type trainingDataHandlerRepoStub struct {
	service.TrainingDataRepository
	exported      []service.TrainingConversation
	summary       *service.TrainingDataSummary
	summaryByDate map[string]*service.TrainingDataSummary
	summaryCalls  int
	rangeCalls    int
}

func (s *trainingDataHandlerRepoStub) SummaryRange(ctx context.Context, start, end time.Time) (*service.TrainingDataSummary, error) {
	s.rangeCalls++
	result := &service.TrainingDataSummary{}
	for day := start; day.Before(end); day = day.AddDate(0, 0, 1) {
		daySummary := s.summaryByDate[day.Format("2006-01-02")]
		if daySummary == nil {
			daySummary = s.summary
		}
		var records int64
		if daySummary != nil {
			records = daySummary.TodayRecords
			if daySummary.LatestDataTime != nil &&
				(result.LatestDataTime == nil || daySummary.LatestDataTime.After(*result.LatestDataTime)) {
				latest := *daySummary.LatestDataTime
				result.LatestDataTime = &latest
			}
		}
		result.DailyRecords = append(result.DailyRecords, service.TrainingDataDailyRecord{
			Date:    day.Format("2006-01-02"),
			Records: records,
		})
	}
	return result, nil
}

func (s *trainingDataHandlerRepoStub) Export(ctx context.Context, filter service.TrainingDataFilter, limit int) ([]service.TrainingConversation, error) {
	return s.exported, nil
}

func (s *trainingDataHandlerRepoStub) List(ctx context.Context, filter service.TrainingDataFilter, params pagination.PaginationParams) ([]service.TrainingConversation, *pagination.PaginationResult, error) {
	return nil, &pagination.PaginationResult{}, nil
}

func (s *trainingDataHandlerRepoStub) Summary(ctx context.Context, start, end time.Time) (*service.TrainingDataSummary, error) {
	s.summaryCalls++
	if summary := s.summaryByDate[start.Format("2006-01-02")]; summary != nil {
		return summary, nil
	}
	if s.summary != nil {
		return s.summary, nil
	}
	return &service.TrainingDataSummary{}, nil
}

func TestTrainingDataSummaryDefaultsToOneDay(t *testing.T) {
	gin.SetMode(gin.TestMode)
	repo := &trainingDataHandlerRepoStub{summary: &service.TrainingDataSummary{TodayRecords: 12}}
	router := gin.New()
	router.GET("/admin/training-data/summary", NewTrainingDataHandler(service.NewTrainingDataService(repo)).Summary)
	req := httptest.NewRequest(http.MethodGet, "/admin/training-data/summary?date=2026-08-16&timezone=Asia/Shanghai", nil)
	rec := httptest.NewRecorder()

	router.ServeHTTP(rec, req)

	require.Equal(t, http.StatusOK, rec.Code)
	require.Equal(t, 1, repo.rangeCalls)
	require.Zero(t, repo.summaryCalls)
}

func TestTrainingDataSummaryRejectsInvalidTimezone(t *testing.T) {
	gin.SetMode(gin.TestMode)
	repo := &trainingDataHandlerRepoStub{}
	router := gin.New()
	router.GET("/admin/training-data/summary", NewTrainingDataHandler(service.NewTrainingDataService(repo)).Summary)
	req := httptest.NewRequest(http.MethodGet, "/admin/training-data/summary?timezone=Not/A_Timezone", nil)
	rec := httptest.NewRecorder()

	router.ServeHTTP(rec, req)

	require.Equal(t, http.StatusBadRequest, rec.Code)
	require.Zero(t, repo.rangeCalls)
	require.Zero(t, repo.summaryCalls)
}

func TestTrainingDataSummaryReturnsRecentDailyCaptureCounts(t *testing.T) {
	gin.SetMode(gin.TestMode)
	latestYesterday := time.Date(2026, 8, 15, 12, 0, 0, 0, time.UTC)
	repo := &trainingDataHandlerRepoStub{summaryByDate: map[string]*service.TrainingDataSummary{
		"2026-08-14": {TodayRecords: 107063},
		"2026-08-15": {TodayRecords: 83099, LatestDataTime: &latestYesterday},
		"2026-08-16": {TodayRecords: 56559},
	}}

	router := gin.New()
	router.GET("/admin/training-data/summary", NewTrainingDataHandler(service.NewTrainingDataService(repo)).Summary)
	req := httptest.NewRequest(http.MethodGet, "/admin/training-data/summary?date=2026-08-16&timezone=Asia/Shanghai&days=3", nil)
	rec := httptest.NewRecorder()

	router.ServeHTTP(rec, req)

	require.Equal(t, http.StatusOK, rec.Code)
	var envelope struct {
		Data struct {
			TodayRecords   int64  `json:"today_records"`
			LatestDataTime string `json:"latest_data_time"`
			DailyRecords   []struct {
				Date    string `json:"date"`
				Records int64  `json:"records"`
			} `json:"daily_records"`
		} `json:"data"`
	}
	require.NoError(t, json.Unmarshal(rec.Body.Bytes(), &envelope))
	require.Equal(t, int64(56559), envelope.Data.TodayRecords)
	require.Equal(t, latestYesterday.Format(time.RFC3339), envelope.Data.LatestDataTime)
	require.Equal(t, 1, repo.rangeCalls)
	require.Zero(t, repo.summaryCalls)
	require.Len(t, envelope.Data.DailyRecords, 3)
	require.Equal(t, []string{"2026-08-14", "2026-08-15", "2026-08-16"}, []string{
		envelope.Data.DailyRecords[0].Date,
		envelope.Data.DailyRecords[1].Date,
		envelope.Data.DailyRecords[2].Date,
	})
	require.Equal(t, []int64{107063, 83099, 56559}, []int64{
		envelope.Data.DailyRecords[0].Records,
		envelope.Data.DailyRecords[1].Records,
		envelope.Data.DailyRecords[2].Records,
	})
}

func TestTrainingDataSummaryReturnsLiveDBSummary(t *testing.T) {
	gin.SetMode(gin.TestMode)
	latest := time.Date(2026, 6, 28, 19, 44, 55, 0, time.UTC)
	repo := &trainingDataHandlerRepoStub{summary: &service.TrainingDataSummary{
		TodayRecords:   1510,
		LatestDataTime: &latest,
	}}

	router := gin.New()
	router.GET("/admin/training-data/summary", NewTrainingDataHandler(service.NewTrainingDataService(repo)).Summary)
	req := httptest.NewRequest(http.MethodGet, "/admin/training-data/summary?date=2026-06-28&timezone=Asia/Shanghai", nil)
	rec := httptest.NewRecorder()

	router.ServeHTTP(rec, req)

	require.Equal(t, http.StatusOK, rec.Code)
	var envelope struct {
		Code int `json:"code"`
		Data struct {
			TodayRecords   int64  `json:"today_records"`
			LatestDataTime string `json:"latest_data_time"`
			TodayDate      string `json:"today_date"`
		} `json:"data"`
	}
	require.NoError(t, json.Unmarshal(rec.Body.Bytes(), &envelope))
	require.Equal(t, 0, envelope.Code)
	require.Equal(t, int64(1510), envelope.Data.TodayRecords)
	require.Equal(t, "2026-06-28", envelope.Data.TodayDate)
	require.NotEmpty(t, envelope.Data.LatestDataTime)
}

func TestTrainingDataExportWritesOpenAIChatJSONL(t *testing.T) {
	gin.SetMode(gin.TestMode)
	createdAt := time.Date(2026, 6, 27, 2, 30, 0, 0, time.UTC)
	repo := &trainingDataHandlerRepoStub{exported: []service.TrainingConversation{{
		Model:       "gpt-5-requested",
		UserInput:   json.RawMessage(`[{"role":"system","content":"You are a coding agent."},{"role":"user","content":"debug code"},{"role":"assistant","content":"","tool_calls":[{"id":"call_1","type":"function","function":{"name":"apply_patch","arguments":"{}"}}]},{"role":"tool","tool_call_id":"call_1","content":"ok"},{"role":"assistant","content":"patched"},{"role":"user","content":"thanks"}]`),
		Metadata:    json.RawMessage(`{"source_model":"gpt-5","tool_definitions":[{"name":"apply_patch","description":"Apply a patch"}],"effective_rounds":3,"tool_use_count":1,"tool_result_count":1,"tool_pair_rate":1,"training_filter":"luchikey_h1_h4_d1"}`),
		RequestHash: "dedup-hash",
		CreatedAt:   createdAt,
	}}}

	router := gin.New()
	router.GET("/admin/training-data/export", NewTrainingDataHandler(service.NewTrainingDataService(repo)).Export)
	req := httptest.NewRequest(http.MethodGet, "/admin/training-data/export?limit=1", nil)
	rec := httptest.NewRecorder()

	router.ServeHTTP(rec, req)

	require.Equal(t, http.StatusOK, rec.Code)
	require.Contains(t, rec.Header().Get("Content-Type"), "application/x-ndjson")

	var line map[string]any
	require.NoError(t, json.Unmarshal(rec.Body.Bytes(), &line))
	require.Contains(t, line, "messages")
	require.Contains(t, line, "metadata")
	require.Contains(t, line, "created_at")
	require.Len(t, line, 3)
	require.NotContains(t, line, "user_input")
	require.NotContains(t, line, "request_hash")

	messages, ok := line["messages"].([]any)
	require.True(t, ok)
	require.Len(t, messages, 6)
	roles := make([]string, 0, len(messages))
	for _, raw := range messages {
		msg, ok := raw.(map[string]any)
		require.True(t, ok)
		roles = append(roles, msg["role"].(string))
	}
	require.Equal(t, []string{"system", "user", "assistant", "tool", "assistant", "user"}, roles)
	assistant := messages[2].(map[string]any)
	toolCalls, ok := assistant["tool_calls"].([]any)
	require.True(t, ok)
	require.Len(t, toolCalls, 1)
	require.Equal(t, "apply_patch", toolCalls[0].(map[string]any)["function"].(map[string]any)["name"])
	require.Equal(t, "call_1", messages[3].(map[string]any)["tool_call_id"])

	metadata, ok := line["metadata"].(map[string]any)
	require.True(t, ok)
	require.Equal(t, "gpt-5", metadata["model"])
	require.Equal(t, "dedup-hash", metadata["full_dedup_hash"])
	require.Equal(t, "luchikey_h1_h4_d1", metadata["training_filter"])
	tools, ok := metadata["tools"].([]any)
	require.True(t, ok)
	require.Len(t, tools, 1)
	require.Equal(t, "apply_patch", tools[0].(map[string]any)["name"])
	require.Equal(t, "Apply a patch", tools[0].(map[string]any)["description"])
}
